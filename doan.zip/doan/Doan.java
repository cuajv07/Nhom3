/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.classproject.doan;

/**
 *
 * @author NTHie
 */
public class Doan {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
