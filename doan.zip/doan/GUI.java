/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.classproject.doan;

import com.opencsv.CSVParser;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
public class GUI extends javax.swing.JFrame {
    static final String curr_dir = System.getProperty("user.dir");
    static final String separator = File.separator;
    static final String JSON_PATH_READ = curr_dir + separator + "Data_Phong" + separator + "Phong.json";
    static final String JSON_PATH_WRITE = curr_dir + separator + "Data_Phong" + separator + "write.json";
    static final String CSV_PATH_WRITE = curr_dir + separator + "Data_Phong" + separator + "write.csv";
    static final String CSV_PATH_Filter = curr_dir + separator + "Data_Phong" + separator + "filter.csv";
    static ArrayList<Phong> listdata = new ArrayList<>();
    static ArrayList<Phong> list_filter = new ArrayList<>();
    static ArrayList<Phong> list_filter_deatail = new ArrayList<>();
    static final String JSON_PATH_READ_KH = curr_dir + separator + "Data_Phong" + separator + "Phong.json";
    static final String CSV_WRITE_PHONG = curr_dir + separator + "Data_Phong" + separator + "write.csv";
    static final String JSON_PATH_WR_KH = curr_dir + separator + "Data_KH" + separator + "Khach_hang.json";
    static final String WRITE_CSV_KH = curr_dir + separator + "Data_KH" + separator + "KH.csv";
    static ArrayList<Khach_hang> list_KH = new ArrayList<>();
    static ArrayList<Phong> list_Phong = new ArrayList<>();
    static ArrayList<Hoa_don> list_Hoadon = new ArrayList<>();
    static QuanLiHoaDon qlhd = new QuanLiHoaDon();
    static QuanLiPhong qlp = new QuanLiPhong();
    static ArrayList<Hoa_don> list_filter_HD = new ArrayList<>();
    static final String JSON_PATH_WRITE_HD = curr_dir + separator + "Data_HoaDon" + separator + "Hoadon.json";
    static final String CSV_PATH_WRITE_HD = curr_dir + separator + "Data_HoaDon" + separator + "HoaDon.csv";
    static final String CSV_Filter_HD = curr_dir + separator + "Data_HoaDon" + separator + "filterHD.csv";
    int roomNum;
    boolean nameKey = false;
    boolean phoneKey = false;
    boolean addressKey = false;
    boolean roomKey = false;
    boolean roomCodeKey = false;
    boolean deleteCusKey = false;
    boolean fixCusCodeKey = false;
    boolean fixCusNameKey = false;
    boolean fixCusPhoneKey = false;
    boolean addBillKey = false;
    boolean deleteBillKey = false;
    int roomTableKey = 0;
    int cusTableKey = 0;
    int billFilterKey = 0;
    int billListKey = 0;
    File csv_file = new File(CSV_PATH_WRITE);
    File cusListFile = new File(WRITE_CSV_KH);
    File billFilterFile = new File(CSV_Filter_HD);
    File billList = new File(CSV_PATH_WRITE_HD);
    DefaultTableModel billListData = new DefaultTableModel();
    DefaultTableModel billFilterData = new DefaultTableModel();
    DefaultTableModel cusListData = new DefaultTableModel();
    DefaultTableModel csv_data = new DefaultTableModel();
    public void showBillList() throws IOException
    {
        try {
            int start = 0;int i = 0;
            InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(billList));
            org.apache.commons.csv.CSVParser cSVParser = CSVFormat.DEFAULT.parse(inputStreamReader);
            for(CSVRecord cSVRecord : cSVParser)
            {
                if(start == 0 && billListKey == 0)
                {
                    start = 1;
                    billListData.addColumn(cSVRecord.get(0));
                    billListData.addColumn(cSVRecord.get(1));
                    billListData.addColumn(cSVRecord.get(2));
                    billListData.addColumn(cSVRecord.get(3));
                }
                else
                {
                    if(i != 0)
                    {
                    Vector row = new Vector();
                    row.add(cSVRecord.get(0));
                    row.add(cSVRecord.get(1));
                    row.add(cSVRecord.get(2));
                    row.add(cSVRecord.get(3));
                    billListData.addRow(row);
                    }
                }
                ++i;
            }
            jTable3.setModel(billListData);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void showBillFilter() throws IOException
    {
        try {
            int start = 0;int i = 0;
            InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(billFilterFile));
            org.apache.commons.csv.CSVParser cSVParser = CSVFormat.DEFAULT.parse(inputStreamReader);
            for(CSVRecord cSVRecord : cSVParser)
            {
                if(start == 0 && billFilterKey == 0)
                {
                    start = 1;
                    billFilterData.addColumn(cSVRecord.get(0));
                    billFilterData.addColumn(cSVRecord.get(1));
                    billFilterData.addColumn(cSVRecord.get(2));
                    billFilterData.addColumn(cSVRecord.get(3));
                }
                else
                {
                    if(i != 0)
                    {
                    Vector row = new Vector();
                    row.add(cSVRecord.get(0));
                    row.add(cSVRecord.get(1));
                    row.add(cSVRecord.get(2));
                    row.add(cSVRecord.get(3));
                    billFilterData.addRow(row);
                    }
                }
                ++i;
            }
            jTable2.setModel(billFilterData);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void showCusList() throws IOException
    {
        try {
            int start = 0;int i = 0;
            InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(cusListFile));
            org.apache.commons.csv.CSVParser cSVParser = CSVFormat.DEFAULT.parse(inputStreamReader);
            for(CSVRecord cSVRecord : cSVParser)
            {
                if(start == 0 && cusTableKey == 0)
                {
                    start = 1;
                    cusListData.addColumn(cSVRecord.get(0));
                    cusListData.addColumn(cSVRecord.get(1));
                    cusListData.addColumn(cSVRecord.get(2));
                    cusListData.addColumn(cSVRecord.get(3));
                }
                else
                {
                    if(i != 0)
                    {
                    Vector row = new Vector();
                    row.add(cSVRecord.get(0));
                    row.add(cSVRecord.get(1));
                    row.add(cSVRecord.get(2));
                    row.add(cSVRecord.get(3));
                    cusListData.addRow(row);
                    }
                }
                ++i;
            }
            jTable1.setModel(cusListData);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void showTable() throws IOException
    {
        try {
            int start = 0;int i = 0;
            InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(csv_file));
            org.apache.commons.csv.CSVParser cSVParser = CSVFormat.DEFAULT.parse(inputStreamReader);
            for(CSVRecord cSVRecord : cSVParser)
            {
                if(start == 0 && roomTableKey == 0)
                {
                    start = 1;
                    csv_data.addColumn(cSVRecord.get(0));
                    csv_data.addColumn(cSVRecord.get(1));
                    csv_data.addColumn(cSVRecord.get(2));
                    csv_data.addColumn(cSVRecord.get(3));
                    csv_data.addColumn(cSVRecord.get(4));
                    csv_data.addColumn(cSVRecord.get(5));
                    csv_data.addColumn(cSVRecord.get(6));
                    csv_data.addColumn(cSVRecord.get(7));
                }
                else
                {
                    if(i != 0)
                    {
                    Vector row = new Vector();
                    row.add(cSVRecord.get(0));
                    row.add(cSVRecord.get(1));
                    row.add(cSVRecord.get(2));
                    row.add(cSVRecord.get(3));
                    row.add(cSVRecord.get(4));
                    row.add(cSVRecord.get(5));
                    row.add(cSVRecord.get(6));
                    row.add(cSVRecord.get(7));
                    csv_data.addRow(row);
                    }
                }
                ++i;
            }
            roomDataTbl.setModel(csv_data);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Creates new form GUI
     */
    public GUI() {
        initComponents();
        String str = "<html><u> Xem danh sách vừa lọc </u></html>";
        jLabel21.setText(str);
        Op1Pan.setVisible(false);
        Op2Pan.setVisible(false);
        Op3Pan.setVisible(false);
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(false);
        SecFloorBox.setVisible(false);
        ThrdFloorBox.setVisible(false);
        FourthFloorBox.setVisible(false);
        FifthFloorBox.setVisible(false);
        jLabel5.setVisible(false);
        jLabel4.setVisible(false);
        BlankRoomButt.setVisible(false);
        OrderRoomButt.setVisible(false);
        UsingRoomButt.setVisible(false);
        RefreshButt.setVisible(false);
        BlankRoomButt.setEnabled(false);
        OrderRoomButt.setEnabled(false);
        UsingRoomButt.setEnabled(false);
        DeleteRoomPan.setVisible(false);
        UpdateOrderPan.setVisible(false);
        updateReturnDatePan.setVisible(false);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        RoomFilterPan.setVisible(false);
        addCusPan.setVisible(false);
        roomListPan.setVisible(false);
        deleteCusPan.setVisible(false);
        fixCusInfoPan.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        HeadingPan = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        MenuPan = new javax.swing.JPanel();
        roomManageButt = new javax.swing.JButton();
        customersManageB = new javax.swing.JButton();
        billManageButt = new javax.swing.JButton();
        Op1Pan = new javax.swing.JPanel();
        RoomManagementPan = new javax.swing.JPanel();
        ChangeStatus = new javax.swing.JButton();
        BookDate = new javax.swing.JButton();
        ReturnDate = new javax.swing.JButton();
        FilterButt = new javax.swing.JButton();
        roomListButt = new javax.swing.JButton();
        ChangeStatusPan = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        FloorBox = new javax.swing.JComboBox<>();
        RoomBox = new javax.swing.JComboBox<>();
        ConfirmButt = new javax.swing.JButton();
        SecFloorBox = new javax.swing.JComboBox<>();
        ThrdFloorBox = new javax.swing.JComboBox<>();
        FourthFloorBox = new javax.swing.JComboBox<>();
        FifthFloorBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        BlankRoomButt = new javax.swing.JButton();
        OrderRoomButt = new javax.swing.JButton();
        UsingRoomButt = new javax.swing.JButton();
        RefreshButt = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        updateOrderDate = new javax.swing.JPanel();
        DeleteRoomButt = new javax.swing.JButton();
        UpdateRoomButt = new javax.swing.JButton();
        DeleteRoomPan = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        DeleteRoomF = new javax.swing.JTextField();
        ConfirmDelete = new javax.swing.JButton();
        NotifyLb = new javax.swing.JLabel();
        UpdateOrderPan = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        UpdateRoomF = new javax.swing.JTextField();
        ConfirmChange = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        UpdateDayBox = new javax.swing.JComboBox<>();
        UpdateMonthBox = new javax.swing.JComboBox<>();
        UpdateYearBox = new javax.swing.JComboBox<>();
        RefreshUpdate = new javax.swing.JButton();
        NotifyLb2 = new javax.swing.JLabel();
        updateReturnDatePan = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        DeleteReturnDateButt = new javax.swing.JButton();
        updateReturnDateButt = new javax.swing.JButton();
        deleteReRoomPan = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        deleteReRoomF = new javax.swing.JTextField();
        confirmDeleteRRButt = new javax.swing.JButton();
        NotifyLb3 = new javax.swing.JLabel();
        updateReRoomPan = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        updateRRfield = new javax.swing.JTextField();
        confirmUpdateButt = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        uDateBox = new javax.swing.JComboBox<>();
        uMonthBox = new javax.swing.JComboBox<>();
        uYearBox = new javax.swing.JComboBox<>();
        refreshUpdateButt = new javax.swing.JButton();
        NotifyLb4 = new javax.swing.JLabel();
        RoomFilterPan = new javax.swing.JPanel();
        roomStatusFilterP = new javax.swing.JPanel();
        roomStatusFilterB = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        blankFilterB = new javax.swing.JButton();
        orderedFilterB = new javax.swing.JButton();
        usingFilterB = new javax.swing.JButton();
        roomStoFilterP = new javax.swing.JPanel();
        roomStoFilterB = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        doubleRoomB = new javax.swing.JButton();
        tripleRoomB = new javax.swing.JButton();
        fourRoomB = new javax.swing.JButton();
        roomOrderFilterP = new javax.swing.JPanel();
        roomOrderFilterB = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        orderDateFilterBox = new javax.swing.JComboBox<>();
        confirmOfilterB = new javax.swing.JButton();
        roomReturnFilterP = new javax.swing.JPanel();
        roomReturnFilterB = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        returnDateFilterBox = new javax.swing.JComboBox<>();
        confirmRfilterB = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        roomListPan = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        roomDataTbl = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        Op2Pan = new javax.swing.JPanel();
        Menu2Pan = new javax.swing.JPanel();
        addCusButt = new javax.swing.JButton();
        deleteCusButt = new javax.swing.JButton();
        fixCusButt = new javax.swing.JButton();
        customersList = new javax.swing.JButton();
        addCusPan = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        cusNameField = new javax.swing.JTextField();
        phoneField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        addressField = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        checkButt = new javax.swing.JButton();
        roomToAddField = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        cusCodeField = new javax.swing.JTextField();
        completeButt = new javax.swing.JButton();
        confirmCheckBox = new javax.swing.JCheckBox();
        deleteCusPan = new javax.swing.JPanel();
        deleteCusField = new javax.swing.JTextField();
        confirmDeleteCusB = new javax.swing.JButton();
        fixCusInfoPan = new javax.swing.JPanel();
        fixCusCodeF = new javax.swing.JTextField();
        findButt = new javax.swing.JButton();
        fixCusNameF = new javax.swing.JTextField();
        fixCusAdF = new javax.swing.JTextField();
        fixCusPhoneF = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        cusListPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Op3Pan = new javax.swing.JPanel();
        Menu3Pan = new javax.swing.JPanel();
        addBillButt = new javax.swing.JButton();
        deleteBillButt = new javax.swing.JButton();
        filterBillButt = new javax.swing.JButton();
        incomeBymonthB = new javax.swing.JButton();
        billListButt = new javax.swing.JButton();
        addBillPan = new javax.swing.JPanel();
        addBillField = new javax.swing.JTextField();
        searchCusB = new javax.swing.JButton();
        deleteBillPan = new javax.swing.JPanel();
        deleteBillField = new javax.swing.JTextField();
        searchDeleteB = new javax.swing.JButton();
        billFilterPan = new javax.swing.JPanel();
        dayBillFilBox = new javax.swing.JComboBox<>();
        monthBillFillBox = new javax.swing.JComboBox<>();
        billFilterButt = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        monthIncomePan = new javax.swing.JPanel();
        calculateIncomePan = new javax.swing.JPanel();
        displayPan = new javax.swing.JPanel();
        line1LB = new javax.swing.JLabel();
        line2LB = new javax.swing.JLabel();
        calculatePan = new javax.swing.JPanel();
        calculateMonthBox = new javax.swing.JComboBox<>();
        calculateButt = new javax.swing.JButton();
        refreshCalculateB = new javax.swing.JButton();
        billListPan = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        HeadingPan.setBackground(new java.awt.Color(0, 153, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Lựa chọn thao tác ");

        javax.swing.GroupLayout HeadingPanLayout = new javax.swing.GroupLayout(HeadingPan);
        HeadingPan.setLayout(HeadingPanLayout);
        HeadingPanLayout.setHorizontalGroup(
            HeadingPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HeadingPanLayout.createSequentialGroup()
                .addGap(370, 370, 370)
                .addComponent(jLabel2)
                .addContainerGap(394, Short.MAX_VALUE))
        );
        HeadingPanLayout.setVerticalGroup(
            HeadingPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HeadingPanLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel2)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        getContentPane().add(HeadingPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, -1));

        MenuPan.setBackground(new java.awt.Color(204, 255, 204));

        roomManageButt.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        roomManageButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Edit.png")); // NOI18N
        roomManageButt.setText("Quản lý phòng");
        roomManageButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        roomManageButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        roomManageButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        roomManageButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomManageButtActionPerformed(evt);
            }
        });

        customersManageB.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        customersManageB.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Users.png")); // NOI18N
        customersManageB.setText("Quản lý khách hàng");
        customersManageB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        customersManageB.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        customersManageB.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        customersManageB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customersManageBActionPerformed(evt);
            }
        });

        billManageButt.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        billManageButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Price list.png")); // NOI18N
        billManageButt.setText("Quản lý hóa đơn");
        billManageButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        billManageButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        billManageButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        billManageButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billManageButtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MenuPanLayout = new javax.swing.GroupLayout(MenuPan);
        MenuPan.setLayout(MenuPanLayout);
        MenuPanLayout.setHorizontalGroup(
            MenuPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuPanLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(MenuPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(customersManageB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roomManageButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(billManageButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        MenuPanLayout.setVerticalGroup(
            MenuPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuPanLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(roomManageButt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(customersManageB, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addComponent(billManageButt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        getContentPane().add(MenuPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 240, 550));

        Op1Pan.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        Op1Pan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RoomManagementPan.setBackground(new java.awt.Color(255, 255, 204));

        ChangeStatus.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Create.png")); // NOI18N
        ChangeStatus.setText("Sửa đổi trạng thái");
        ChangeStatus.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ChangeStatus.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ChangeStatus.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        ChangeStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangeStatusActionPerformed(evt);
            }
        });

        BookDate.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Calendar.png")); // NOI18N
        BookDate.setText("Cập nhật ngày đặt phòng");
        BookDate.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        BookDate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BookDate.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BookDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BookDateActionPerformed(evt);
            }
        });

        ReturnDate.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Date.png")); // NOI18N
        ReturnDate.setText("Cập nhật ngày trả phòng");
        ReturnDate.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ReturnDate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ReturnDate.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        ReturnDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnDateActionPerformed(evt);
            }
        });

        FilterButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Notes.png")); // NOI18N
        FilterButt.setText("Lọc");
        FilterButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FilterButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        FilterButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        FilterButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FilterButtActionPerformed(evt);
            }
        });

        roomListButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Numbered list.png")); // NOI18N
        roomListButt.setText("Danh sách phòng");
        roomListButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        roomListButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        roomListButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        roomListButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomListButtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout RoomManagementPanLayout = new javax.swing.GroupLayout(RoomManagementPan);
        RoomManagementPan.setLayout(RoomManagementPanLayout);
        RoomManagementPanLayout.setHorizontalGroup(
            RoomManagementPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RoomManagementPanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ChangeStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BookDate)
                .addGap(18, 18, 18)
                .addComponent(ReturnDate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(FilterButt, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(roomListButt, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        RoomManagementPanLayout.setVerticalGroup(
            RoomManagementPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RoomManagementPanLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(RoomManagementPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RoomManagementPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(roomListButt, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ChangeStatus, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(BookDate, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(RoomManagementPanLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(RoomManagementPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ReturnDate)
                            .addComponent(FilterButt, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        Op1Pan.add(RoomManagementPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 750, 130));

        ChangeStatusPan.setBackground(new java.awt.Color(204, 255, 255));
        ChangeStatusPan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        jLabel3.setText("Tên phòng cần thay đổi :");
        ChangeStatusPan.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 25, -1, -1));

        FloorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tầng", "1", "2", "3", "4", "5", " " }));
        FloorBox.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FloorBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FloorBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(FloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(255, 22, -1, -1));

        RoomBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số phòng", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110" }));
        RoomBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RoomBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoomBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(RoomBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, -1, -1));

        ConfirmButt.setText("Xác nhận");
        ConfirmButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ConfirmButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmButtActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(ConfirmButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(605, 22, -1, -1));

        SecFloorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số phòng", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210" }));
        SecFloorBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SecFloorBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(SecFloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, -1, -1));

        ThrdFloorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số phòng", "301", "302", "303", "304", "305", "306", "307", "308", "309", "310" }));
        ThrdFloorBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThrdFloorBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(ThrdFloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, -1, -1));

        FourthFloorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số phòng", "401", "402", "403", "404", "405", "406", "407", "408", "409", "410" }));
        FourthFloorBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FourthFloorBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(FourthFloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, -1, -1));

        FifthFloorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Số phòng", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510" }));
        FifthFloorBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FifthFloorBoxActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(FifthFloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel4.setText("Lựa chọn trạng thái phòng");
        ChangeStatusPan.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, -1, -1));

        BlankRoomButt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BlankRoomButt.setText("Trống");
        BlankRoomButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BlankRoomButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BlankRoomButtActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(BlankRoomButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 120, -1));

        OrderRoomButt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        OrderRoomButt.setText("Đã đặt trước");
        OrderRoomButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        OrderRoomButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrderRoomButtActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(OrderRoomButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 240, 120, -1));

        UsingRoomButt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UsingRoomButt.setText("Đang sử dụng");
        UsingRoomButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        UsingRoomButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsingRoomButtActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(UsingRoomButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, -1, -1));

        RefreshButt.setText("Làm mới");
        RefreshButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RefreshButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtActionPerformed(evt);
            }
        });
        ChangeStatusPan.add(RefreshButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 310, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        ChangeStatusPan.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, 50, 30));

        Op1Pan.add(ChangeStatusPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 126, 750, 430));

        updateOrderDate.setBackground(new java.awt.Color(204, 255, 255));

        DeleteRoomButt.setFont(new java.awt.Font("Segoe UI Black", 3, 14)); // NOI18N
        DeleteRoomButt.setText("Xóa ngày đặt phòng");
        DeleteRoomButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DeleteRoomButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteRoomButtActionPerformed(evt);
            }
        });

        UpdateRoomButt.setFont(new java.awt.Font("Segoe UI Black", 3, 14)); // NOI18N
        UpdateRoomButt.setText("Cập nhật ngày đặt phòng");
        UpdateRoomButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        UpdateRoomButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateRoomButtActionPerformed(evt);
            }
        });

        DeleteRoomPan.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        jLabel6.setText("Nhập số phòng cần xóa : (101 - 510)");

        DeleteRoomF.setText("Số phòng");
        DeleteRoomF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                DeleteRoomFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                DeleteRoomFFocusLost(evt);
            }
        });
        DeleteRoomF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteRoomFActionPerformed(evt);
            }
        });

        ConfirmDelete.setText("Xác nhận");
        ConfirmDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmDeleteActionPerformed(evt);
            }
        });

        NotifyLb.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        NotifyLb.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout DeleteRoomPanLayout = new javax.swing.GroupLayout(DeleteRoomPan);
        DeleteRoomPan.setLayout(DeleteRoomPanLayout);
        DeleteRoomPanLayout.setHorizontalGroup(
            DeleteRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DeleteRoomPanLayout.createSequentialGroup()
                .addGroup(DeleteRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(DeleteRoomPanLayout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(NotifyLb, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(DeleteRoomPanLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(DeleteRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(DeleteRoomF))
                        .addGap(61, 61, 61)
                        .addComponent(ConfirmDelete)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        DeleteRoomPanLayout.setVerticalGroup(
            DeleteRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DeleteRoomPanLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(DeleteRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DeleteRoomF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ConfirmDelete))
                .addGap(27, 27, 27)
                .addComponent(NotifyLb, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        UpdateOrderPan.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        jLabel7.setText("Nhập số phòng cần thay đổi : (101-510)");

        UpdateRoomF.setText("Số phòng");
        UpdateRoomF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                UpdateRoomFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                UpdateRoomFFocusLost(evt);
            }
        });
        UpdateRoomF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateRoomFActionPerformed(evt);
            }
        });

        ConfirmChange.setText("Xác nhận");
        ConfirmChange.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ConfirmChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmChangeActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        jLabel8.setText("Thời gian đặt phòng :");

        UpdateDayBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ngày", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        UpdateDayBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateDayBoxActionPerformed(evt);
            }
        });

        UpdateMonthBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        UpdateMonthBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateMonthBoxActionPerformed(evt);
            }
        });

        UpdateYearBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Năm", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039", "2040" }));
        UpdateYearBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateYearBoxActionPerformed(evt);
            }
        });

        RefreshUpdate.setText("Làm mới");
        RefreshUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        RefreshUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshUpdateActionPerformed(evt);
            }
        });

        NotifyLb2.setFont(new java.awt.Font("Segoe UI Black", 2, 13)); // NOI18N
        NotifyLb2.setForeground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout UpdateOrderPanLayout = new javax.swing.GroupLayout(UpdateOrderPan);
        UpdateOrderPan.setLayout(UpdateOrderPanLayout);
        UpdateOrderPanLayout.setHorizontalGroup(
            UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdateOrderPanLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UpdateOrderPanLayout.createSequentialGroup()
                        .addComponent(RefreshUpdate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ConfirmChange)
                        .addGap(16, 16, 16))
                    .addGroup(UpdateOrderPanLayout.createSequentialGroup()
                        .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(NotifyLb2, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(UpdateOrderPanLayout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(18, 18, 18)
                                    .addComponent(UpdateDayBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(UpdateMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(UpdateYearBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(UpdateRoomF))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        UpdateOrderPanLayout.setVerticalGroup(
            UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdateOrderPanLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(UpdateRoomF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(UpdateDayBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateYearBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(NotifyLb2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(UpdateOrderPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RefreshUpdate)
                    .addComponent(ConfirmChange))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout updateOrderDateLayout = new javax.swing.GroupLayout(updateOrderDate);
        updateOrderDate.setLayout(updateOrderDateLayout);
        updateOrderDateLayout.setHorizontalGroup(
            updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updateOrderDateLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(DeleteRoomButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(UpdateRoomButt, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DeleteRoomPan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(UpdateOrderPan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        updateOrderDateLayout.setVerticalGroup(
            updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updateOrderDateLayout.createSequentialGroup()
                .addGroup(updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(updateOrderDateLayout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(DeleteRoomButt))
                    .addGroup(updateOrderDateLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(DeleteRoomPan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(updateOrderDateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(updateOrderDateLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(UpdateOrderPan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updateOrderDateLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(UpdateRoomButt)
                        .addGap(126, 126, 126))))
        );

        Op1Pan.add(updateOrderDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 750, 430));

        updateReturnDatePan.setBackground(new java.awt.Color(204, 255, 255));
        updateReturnDatePan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        DeleteReturnDateButt.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        DeleteReturnDateButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Trash.png")); // NOI18N
        DeleteReturnDateButt.setText("Xóa ngày trả phòng");
        DeleteReturnDateButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        DeleteReturnDateButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DeleteReturnDateButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        DeleteReturnDateButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteReturnDateButtActionPerformed(evt);
            }
        });

        updateReturnDateButt.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        updateReturnDateButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Notes.png")); // NOI18N
        updateReturnDateButt.setText("Cập nhật ngày trả phòng");
        updateReturnDateButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        updateReturnDateButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        updateReturnDateButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        updateReturnDateButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateReturnDateButtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addComponent(DeleteReturnDateButt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 262, Short.MAX_VALUE)
                .addComponent(updateReturnDateButt)
                .addGap(91, 91, 91))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DeleteReturnDateButt)
                    .addComponent(updateReturnDateButt))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        updateReturnDatePan.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, -1));

        deleteReRoomPan.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        jLabel9.setText("Nhập số phòng cần xóa (101-510) :");

        deleteReRoomF.setText("Số phòng");
        deleteReRoomF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteReRoomFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                deleteReRoomFFocusLost(evt);
            }
        });

        confirmDeleteRRButt.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        confirmDeleteRRButt.setText("Xác nhận");
        confirmDeleteRRButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        confirmDeleteRRButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmDeleteRRButtActionPerformed(evt);
            }
        });

        NotifyLb3.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        NotifyLb3.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout deleteReRoomPanLayout = new javax.swing.GroupLayout(deleteReRoomPan);
        deleteReRoomPan.setLayout(deleteReRoomPanLayout);
        deleteReRoomPanLayout.setHorizontalGroup(
            deleteReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteReRoomPanLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deleteReRoomF, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(confirmDeleteRRButt)
                .addGap(164, 164, 164))
            .addGroup(deleteReRoomPanLayout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(NotifyLb3, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        deleteReRoomPanLayout.setVerticalGroup(
            deleteReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteReRoomPanLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(deleteReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteReRoomF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmDeleteRRButt))
                .addGap(75, 75, 75)
                .addComponent(NotifyLb3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(138, Short.MAX_VALUE))
        );

        updateReturnDatePan.add(deleteReRoomPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 760, 320));

        updateReRoomPan.setBackground(new java.awt.Color(204, 204, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 3, 14)); // NOI18N
        jLabel10.setText("Nhập số phòng cần cập nhật :");

        updateRRfield.setText("Số phòng");
        updateRRfield.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                updateRRfieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                updateRRfieldFocusLost(evt);
            }
        });

        confirmUpdateButt.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        confirmUpdateButt.setText("Xác nhận ");
        confirmUpdateButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        confirmUpdateButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmUpdateButtActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        jLabel11.setText("Ngày trả phòng mới :");

        uDateBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ngày", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        uDateBox.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        uMonthBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        uMonthBox.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        uMonthBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uMonthBoxActionPerformed(evt);
            }
        });

        uYearBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Năm", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039", "2040" }));
        uYearBox.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        refreshUpdateButt.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        refreshUpdateButt.setText("Làm mới");
        refreshUpdateButt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refreshUpdateButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshUpdateButtActionPerformed(evt);
            }
        });

        NotifyLb4.setFont(new java.awt.Font("Segoe UI Black", 3, 14)); // NOI18N
        NotifyLb4.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout updateReRoomPanLayout = new javax.swing.GroupLayout(updateReRoomPan);
        updateReRoomPan.setLayout(updateReRoomPanLayout);
        updateReRoomPanLayout.setHorizontalGroup(
            updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updateReRoomPanLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(updateReRoomPanLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(updateRRfield))
                    .addGroup(updateReRoomPanLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(55, 55, 55)
                        .addComponent(uDateBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(uMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(71, 71, 71)
                .addComponent(uYearBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(updateReRoomPanLayout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addComponent(NotifyLb4, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addGroup(updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(confirmUpdateButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(refreshUpdateButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(67, 67, 67))
        );
        updateReRoomPanLayout.setVerticalGroup(
            updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updateReRoomPanLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(updateRRfield, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(uDateBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(uMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(uYearBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(updateReRoomPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NotifyLb4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmUpdateButt))
                .addGap(27, 27, 27)
                .addComponent(refreshUpdateButt)
                .addGap(34, 34, 34))
        );

        updateReturnDatePan.add(updateReRoomPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 760, 320));

        Op1Pan.add(updateReturnDatePan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 750, 430));

        RoomFilterPan.setBackground(new java.awt.Color(153, 153, 153));
        RoomFilterPan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        roomStatusFilterP.setBackground(new java.awt.Color(204, 255, 255));
        roomStatusFilterP.setPreferredSize(new java.awt.Dimension(185, 430));

        roomStatusFilterB.setFont(new java.awt.Font("Segoe UI Black", 2, 12)); // NOI18N
        roomStatusFilterB.setText("Lọc trạng thái phòng");
        roomStatusFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomStatusFilterBActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        jLabel12.setText("Lọc trạng thái phòng");

        blankFilterB.setText("Trống");
        blankFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blankFilterBActionPerformed(evt);
            }
        });

        orderedFilterB.setText("Đã đặt trước");
        orderedFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderedFilterBActionPerformed(evt);
            }
        });

        usingFilterB.setText("Đang sử dụng ");
        usingFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usingFilterBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roomStatusFilterPLayout = new javax.swing.GroupLayout(roomStatusFilterP);
        roomStatusFilterP.setLayout(roomStatusFilterPLayout);
        roomStatusFilterPLayout.setHorizontalGroup(
            roomStatusFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomStatusFilterPLayout.createSequentialGroup()
                .addGroup(roomStatusFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roomStatusFilterPLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(roomStatusFilterB))
                    .addGroup(roomStatusFilterPLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel12))
                    .addGroup(roomStatusFilterPLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(roomStatusFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(orderedFilterB, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(blankFilterB, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usingFilterB))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        roomStatusFilterPLayout.setVerticalGroup(
            roomStatusFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomStatusFilterPLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(roomStatusFilterB)
                .addGap(36, 36, 36)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(blankFilterB)
                .addGap(48, 48, 48)
                .addComponent(orderedFilterB)
                .addGap(51, 51, 51)
                .addComponent(usingFilterB)
                .addGap(65, 65, 65))
        );

        RoomFilterPan.add(roomStatusFilterP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 46, 181, 384));

        roomStoFilterP.setBackground(new java.awt.Color(204, 255, 204));
        roomStoFilterP.setPreferredSize(new java.awt.Dimension(185, 357));

        roomStoFilterB.setFont(new java.awt.Font("Segoe UI Black", 2, 12)); // NOI18N
        roomStoFilterB.setText("Lọc sức chứa phòng");
        roomStoFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomStoFilterBActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        jLabel13.setText("Lọc sức chứa phòng");

        doubleRoomB.setText("Phòng đôi");
        doubleRoomB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doubleRoomBActionPerformed(evt);
            }
        });

        tripleRoomB.setText("Phòng ba");
        tripleRoomB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tripleRoomBActionPerformed(evt);
            }
        });

        fourRoomB.setText("Phòng bốn");
        fourRoomB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fourRoomBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roomStoFilterPLayout = new javax.swing.GroupLayout(roomStoFilterP);
        roomStoFilterP.setLayout(roomStoFilterPLayout);
        roomStoFilterPLayout.setHorizontalGroup(
            roomStoFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roomStoFilterPLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(roomStoFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(fourRoomB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tripleRoomB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(doubleRoomB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(56, 56, 56))
            .addGroup(roomStoFilterPLayout.createSequentialGroup()
                .addGroup(roomStoFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roomStoFilterPLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel13))
                    .addGroup(roomStoFilterPLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(roomStoFilterB)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        roomStoFilterPLayout.setVerticalGroup(
            roomStoFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomStoFilterPLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(roomStoFilterB)
                .addGap(37, 37, 37)
                .addComponent(jLabel13)
                .addGap(51, 51, 51)
                .addComponent(doubleRoomB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(tripleRoomB)
                .addGap(48, 48, 48)
                .addComponent(fourRoomB)
                .addGap(67, 67, 67))
        );

        RoomFilterPan.add(roomStoFilterP, new org.netbeans.lib.awtextra.AbsoluteConstraints(187, 46, -1, 384));

        roomOrderFilterP.setBackground(new java.awt.Color(255, 255, 204));
        roomOrderFilterP.setPreferredSize(new java.awt.Dimension(185, 272));

        roomOrderFilterB.setFont(new java.awt.Font("Segoe UI Black", 2, 12)); // NOI18N
        roomOrderFilterB.setText("Lọc ngày đặt phòng");
        roomOrderFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomOrderFilterBActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        jLabel14.setText("Lọc ngày đặt phòng ");

        orderDateFilterBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ngày", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        confirmOfilterB.setText("Xác nhận");
        confirmOfilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmOfilterBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roomOrderFilterPLayout = new javax.swing.GroupLayout(roomOrderFilterP);
        roomOrderFilterP.setLayout(roomOrderFilterPLayout);
        roomOrderFilterPLayout.setHorizontalGroup(
            roomOrderFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomOrderFilterPLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(roomOrderFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(roomOrderFilterB)
                    .addGroup(roomOrderFilterPLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(8, 8, 8)))
                .addGap(25, 25, 25))
            .addGroup(roomOrderFilterPLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(roomOrderFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(confirmOfilterB)
                    .addComponent(orderDateFilterBox, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        roomOrderFilterPLayout.setVerticalGroup(
            roomOrderFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomOrderFilterPLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(roomOrderFilterB)
                .addGap(37, 37, 37)
                .addComponent(jLabel14)
                .addGap(54, 54, 54)
                .addComponent(orderDateFilterBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(confirmOfilterB)
                .addGap(68, 68, 68))
        );

        RoomFilterPan.add(roomOrderFilterP, new org.netbeans.lib.awtextra.AbsoluteConstraints(378, 46, -1, 384));

        roomReturnFilterP.setBackground(new java.awt.Color(255, 255, 255));

        roomReturnFilterB.setFont(new java.awt.Font("Segoe UI Black", 2, 12)); // NOI18N
        roomReturnFilterB.setText("Lọc ngày trả phòng");
        roomReturnFilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomReturnFilterBActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        jLabel15.setText("Lọc ngày trả phòng");

        returnDateFilterBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ngày", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        returnDateFilterBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnDateFilterBoxActionPerformed(evt);
            }
        });

        confirmRfilterB.setText("Xác nhận");
        confirmRfilterB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmRfilterBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout roomReturnFilterPLayout = new javax.swing.GroupLayout(roomReturnFilterP);
        roomReturnFilterP.setLayout(roomReturnFilterPLayout);
        roomReturnFilterPLayout.setHorizontalGroup(
            roomReturnFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomReturnFilterPLayout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(roomReturnFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(roomReturnFilterB)
                    .addGroup(roomReturnFilterPLayout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(9, 9, 9)))
                .addGap(24, 24, 24))
            .addGroup(roomReturnFilterPLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(roomReturnFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(confirmRfilterB)
                    .addComponent(returnDateFilterBox, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        roomReturnFilterPLayout.setVerticalGroup(
            roomReturnFilterPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomReturnFilterPLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(roomReturnFilterB)
                .addGap(39, 39, 39)
                .addComponent(jLabel15)
                .addGap(51, 51, 51)
                .addComponent(returnDateFilterBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                .addComponent(confirmRfilterB)
                .addGap(69, 69, 69))
        );

        RoomFilterPan.add(roomReturnFilterP, new org.netbeans.lib.awtextra.AbsoluteConstraints(569, 46, 190, 384));

        jLabel21.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        jLabel21.setText("Xem danh sách vừa lọc");
        jLabel21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel21MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel21MouseExited(evt);
            }
        });
        RoomFilterPan.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 16, -1, -1));

        Op1Pan.add(RoomFilterPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 750, 430));

        roomListPan.setBackground(new java.awt.Color(0, 204, 153));

        roomDataTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        roomDataTbl.setEnabled(false);
        jScrollPane1.setViewportView(roomDataTbl);

        jLabel20.setFont(new java.awt.Font("Segoe UI Black", 3, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Tự động cập nhật");

        javax.swing.GroupLayout roomListPanLayout = new javax.swing.GroupLayout(roomListPan);
        roomListPan.setLayout(roomListPanLayout);
        roomListPanLayout.setHorizontalGroup(
            roomListPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
            .addGroup(roomListPanLayout.createSequentialGroup()
                .addGap(294, 294, 294)
                .addComponent(jLabel20)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roomListPanLayout.setVerticalGroup(
            roomListPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roomListPanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        Op1Pan.add(roomListPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 750, 430));

        getContentPane().add(Op1Pan, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 750, 550));

        Op2Pan.setBackground(new java.awt.Color(204, 204, 204));
        Op2Pan.setPreferredSize(new java.awt.Dimension(750, 556));
        Op2Pan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu2Pan.setBackground(new java.awt.Color(0, 153, 153));

        addCusButt.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        addCusButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Add.png")); // NOI18N
        addCusButt.setText("Thêm khách hàng ");
        addCusButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addCusButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addCusButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addCusButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCusButtActionPerformed(evt);
            }
        });

        deleteCusButt.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        deleteCusButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Delete.png")); // NOI18N
        deleteCusButt.setText("Xóa khách hàng");
        deleteCusButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteCusButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteCusButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteCusButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCusButtActionPerformed(evt);
            }
        });

        fixCusButt.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        fixCusButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Notes.png")); // NOI18N
        fixCusButt.setText("Sửa thông tin khách hàng");
        fixCusButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fixCusButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fixCusButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        fixCusButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fixCusButtActionPerformed(evt);
            }
        });

        customersList.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        customersList.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Numbered list.png")); // NOI18N
        customersList.setText("Danh sách khách hàng");
        customersList.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        customersList.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        customersList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customersListActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu2PanLayout = new javax.swing.GroupLayout(Menu2Pan);
        Menu2Pan.setLayout(Menu2PanLayout);
        Menu2PanLayout.setHorizontalGroup(
            Menu2PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu2PanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addCusButt)
                .addGap(18, 18, 18)
                .addComponent(deleteCusButt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(fixCusButt)
                .addGap(18, 18, 18)
                .addComponent(customersList)
                .addContainerGap())
        );
        Menu2PanLayout.setVerticalGroup(
            Menu2PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu2PanLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(Menu2PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(customersList, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fixCusButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteCusButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addCusButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        Op2Pan.add(Menu2Pan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, -1));

        addCusPan.setBackground(new java.awt.Color(255, 204, 204));
        addCusPan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setText("___________________________________________________________________________________");
        addCusPan.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 400, -1));

        cusNameField.setBackground(new java.awt.Color(255, 204, 204));
        cusNameField.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        cusNameField.setText("Tên khách hàng");
        cusNameField.setBorder(null);
        cusNameField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cusNameFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                cusNameFieldFocusLost(evt);
            }
        });
        cusNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cusNameFieldActionPerformed(evt);
            }
        });
        addCusPan.add(cusNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 390, 36));

        phoneField.setBackground(new java.awt.Color(255, 204, 204));
        phoneField.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        phoneField.setText("Số điện thoại");
        phoneField.setBorder(null);
        phoneField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                phoneFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                phoneFieldFocusLost(evt);
            }
        });
        addCusPan.add(phoneField, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 400, 30));

        jLabel17.setText("________________________________________________________________________________");
        addCusPan.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 400, -1));

        addressField.setBackground(new java.awt.Color(255, 204, 204));
        addressField.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        addressField.setText("Địa chỉ");
        addressField.setBorder(null);
        addressField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                addressFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                addressFieldFocusLost(evt);
            }
        });
        addressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressFieldActionPerformed(evt);
            }
        });
        addCusPan.add(addressField, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 400, 30));

        jLabel18.setText("_________________________________________________________________________________");
        addCusPan.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 410, -1));

        checkButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Search.png")); // NOI18N
        checkButt.setText("Check");
        checkButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        checkButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        checkButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        checkButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkButtActionPerformed(evt);
            }
        });
        addCusPan.add(checkButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 90, 80, 50));

        roomToAddField.setBackground(new java.awt.Color(255, 204, 204));
        roomToAddField.setFont(new java.awt.Font("Segoe UI Black", 3, 13)); // NOI18N
        roomToAddField.setText("Thêm KH vào phòng (101-510)");
        roomToAddField.setBorder(null);
        roomToAddField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                roomToAddFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                roomToAddFieldFocusLost(evt);
            }
        });
        roomToAddField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomToAddFieldActionPerformed(evt);
            }
        });
        addCusPan.add(roomToAddField, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 200, 400, 30));

        jLabel19.setText("_______________________________________________________________________________");
        addCusPan.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 400, -1));

        cusCodeField.setFont(new java.awt.Font("Segoe UI Black", 0, 13)); // NOI18N
        cusCodeField.setText("Đặt mã KH");
        cusCodeField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cusCodeFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                cusCodeFieldFocusLost(evt);
            }
        });
        cusCodeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cusCodeFieldActionPerformed(evt);
            }
        });
        addCusPan.add(cusCodeField, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 150, 30));

        completeButt.setText("Hoàn thành");
        completeButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeButtActionPerformed(evt);
            }
        });
        addCusPan.add(completeButt, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 290, 100, 30));

        confirmCheckBox.setFont(new java.awt.Font("Segoe UI Black", 1, 13)); // NOI18N
        confirmCheckBox.setText("Xác nhận");
        confirmCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmCheckBoxActionPerformed(evt);
            }
        });
        addCusPan.add(confirmCheckBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, 90, -1));

        Op2Pan.add(addCusPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 119, 750, 440));

        deleteCusPan.setBackground(new java.awt.Color(255, 153, 102));

        deleteCusField.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        deleteCusField.setText("Nhập số phòng cần xóa KH");
        deleteCusField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteCusFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                deleteCusFieldFocusLost(evt);
            }
        });
        deleteCusField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCusFieldActionPerformed(evt);
            }
        });

        confirmDeleteCusB.setFont(new java.awt.Font("Segoe UI Black", 2, 12)); // NOI18N
        confirmDeleteCusB.setText("Xóa");
        confirmDeleteCusB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        confirmDeleteCusB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmDeleteCusBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout deleteCusPanLayout = new javax.swing.GroupLayout(deleteCusPan);
        deleteCusPan.setLayout(deleteCusPanLayout);
        deleteCusPanLayout.setHorizontalGroup(
            deleteCusPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteCusPanLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(deleteCusField, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(confirmDeleteCusB, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(82, Short.MAX_VALUE))
        );
        deleteCusPanLayout.setVerticalGroup(
            deleteCusPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteCusPanLayout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(deleteCusPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteCusField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmDeleteCusB, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(321, Short.MAX_VALUE))
        );

        Op2Pan.add(deleteCusPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 750, 440));

        fixCusInfoPan.setBackground(new java.awt.Color(255, 255, 255));

        fixCusCodeF.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        fixCusCodeF.setText("Nhập mã KH cần sửa");
        fixCusCodeF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fixCusCodeFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fixCusCodeFFocusLost(evt);
            }
        });
        fixCusCodeF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fixCusCodeFActionPerformed(evt);
            }
        });

        findButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Search.png")); // NOI18N
        findButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        findButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findButtActionPerformed(evt);
            }
        });

        fixCusNameF.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        fixCusNameF.setText("Nhập lại tên");
        fixCusNameF.setPreferredSize(new java.awt.Dimension(144, 22));
        fixCusNameF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fixCusNameFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fixCusNameFFocusLost(evt);
            }
        });

        fixCusAdF.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        fixCusAdF.setText("Nhập lại địa chỉ");
        fixCusAdF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fixCusAdFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fixCusAdFFocusLost(evt);
            }
        });

        fixCusPhoneF.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        fixCusPhoneF.setText("Nhập lại SĐT");
        fixCusPhoneF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fixCusPhoneFFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fixCusPhoneFFocusLost(evt);
            }
        });
        fixCusPhoneF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fixCusPhoneFActionPerformed(evt);
            }
        });

        jButton1.setText("Thay đổi");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Thay đổi");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Thay đổi");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout fixCusInfoPanLayout = new javax.swing.GroupLayout(fixCusInfoPan);
        fixCusInfoPan.setLayout(fixCusInfoPanLayout);
        fixCusInfoPanLayout.setHorizontalGroup(
            fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fixCusInfoPanLayout.createSequentialGroup()
                .addContainerGap(159, Short.MAX_VALUE)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(fixCusCodeF, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fixCusAdF, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fixCusNameF, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fixCusPhoneF, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(findButt, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(112, 112, 112))
        );
        fixCusInfoPanLayout.setVerticalGroup(
            fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fixCusInfoPanLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(fixCusCodeF, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(findButt))
                .addGap(41, 41, 41)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fixCusNameF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(52, 52, 52)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fixCusAdF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(56, 56, 56)
                .addGroup(fixCusInfoPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fixCusPhoneF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addContainerGap(124, Short.MAX_VALUE))
        );

        Op2Pan.add(fixCusInfoPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 750, 440));

        cusListPanel.setBackground(new java.awt.Color(204, 255, 204));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.setEnabled(false);
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout cusListPanelLayout = new javax.swing.GroupLayout(cusListPanel);
        cusListPanel.setLayout(cusListPanelLayout);
        cusListPanelLayout.setHorizontalGroup(
            cusListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );
        cusListPanelLayout.setVerticalGroup(
            cusListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cusListPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 70, Short.MAX_VALUE))
        );

        Op2Pan.add(cusListPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 750, 430));

        getContentPane().add(Op2Pan, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 750, 550));

        Op3Pan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu3Pan.setBackground(new java.awt.Color(0, 153, 153));

        addBillButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Add.png")); // NOI18N
        addBillButt.setText("Thêm hóa đơn");
        addBillButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addBillButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addBillButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addBillButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBillButtActionPerformed(evt);
            }
        });

        deleteBillButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Delete.png")); // NOI18N
        deleteBillButt.setText("Xóa hóa đơn");
        deleteBillButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deleteBillButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        deleteBillButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        deleteBillButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBillButtActionPerformed(evt);
            }
        });

        filterBillButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Search.png")); // NOI18N
        filterBillButt.setText("Lọc ngày tháng thanh toán");
        filterBillButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        filterBillButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        filterBillButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        filterBillButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterBillButtActionPerformed(evt);
            }
        });

        incomeBymonthB.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Price list.png")); // NOI18N
        incomeBymonthB.setText("Doanh thu theo tháng");
        incomeBymonthB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        incomeBymonthB.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        incomeBymonthB.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        incomeBymonthB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incomeBymonthBActionPerformed(evt);
            }
        });

        billListButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\List.png")); // NOI18N
        billListButt.setText("Danh sách hóa đơn");
        billListButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        billListButt.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        billListButt.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        billListButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billListButtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu3PanLayout = new javax.swing.GroupLayout(Menu3Pan);
        Menu3Pan.setLayout(Menu3PanLayout);
        Menu3PanLayout.setHorizontalGroup(
            Menu3PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu3PanLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Menu3PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(incomeBymonthB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(billListButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteBillButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addBillButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(Menu3PanLayout.createSequentialGroup()
                        .addComponent(filterBillButt)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        Menu3PanLayout.setVerticalGroup(
            Menu3PanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu3PanLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(addBillButt)
                .addGap(44, 44, 44)
                .addComponent(deleteBillButt)
                .addGap(49, 49, 49)
                .addComponent(filterBillButt)
                .addGap(60, 60, 60)
                .addComponent(incomeBymonthB)
                .addGap(53, 53, 53)
                .addComponent(billListButt)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        Op3Pan.add(Menu3Pan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        addBillPan.setBackground(new java.awt.Color(0, 204, 204));

        addBillField.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        addBillField.setText("Nhập mã khách hàng muốn thêm hoá đơn");
        addBillField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                addBillFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                addBillFieldFocusLost(evt);
            }
        });

        searchCusB.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Search.png")); // NOI18N
        searchCusB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchCusB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchCusBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addBillPanLayout = new javax.swing.GroupLayout(addBillPan);
        addBillPan.setLayout(addBillPanLayout);
        addBillPanLayout.setHorizontalGroup(
            addBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addBillPanLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(addBillField, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addComponent(searchCusB, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        addBillPanLayout.setVerticalGroup(
            addBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addBillPanLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(addBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchCusB, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addBillField, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Op3Pan.add(addBillPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 570, 550));

        deleteBillPan.setBackground(new java.awt.Color(0, 204, 204));

        deleteBillField.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        deleteBillField.setText("Nhập mã KH muốn xóa hóa đơn");
        deleteBillField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteBillFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                deleteBillFieldFocusLost(evt);
            }
        });

        searchDeleteB.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Search.png")); // NOI18N
        searchDeleteB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchDeleteB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchDeleteBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout deleteBillPanLayout = new javax.swing.GroupLayout(deleteBillPan);
        deleteBillPan.setLayout(deleteBillPanLayout);
        deleteBillPanLayout.setHorizontalGroup(
            deleteBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteBillPanLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(deleteBillField, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(searchDeleteB, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89))
        );
        deleteBillPanLayout.setVerticalGroup(
            deleteBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(deleteBillPanLayout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addGroup(deleteBillPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(searchDeleteB, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(deleteBillField))
                .addContainerGap(431, Short.MAX_VALUE))
        );

        Op3Pan.add(deleteBillPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 570, 550));

        billFilterPan.setBackground(new java.awt.Color(204, 255, 204));

        dayBillFilBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ngày", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        dayBillFilBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dayBillFilBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayBillFilBoxActionPerformed(evt);
            }
        });

        monthBillFillBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        monthBillFillBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        billFilterButt.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N
        billFilterButt.setText("Lọc");
        billFilterButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        billFilterButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billFilterButtActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable2.setEnabled(false);
        jScrollPane3.setViewportView(jTable2);

        javax.swing.GroupLayout billFilterPanLayout = new javax.swing.GroupLayout(billFilterPan);
        billFilterPan.setLayout(billFilterPanLayout);
        billFilterPanLayout.setHorizontalGroup(
            billFilterPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billFilterPanLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(billFilterPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(billFilterPanLayout.createSequentialGroup()
                        .addComponent(dayBillFilBox, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(monthBillFillBox, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79)
                        .addComponent(billFilterButt, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(72, Short.MAX_VALUE))
        );
        billFilterPanLayout.setVerticalGroup(
            billFilterPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billFilterPanLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(billFilterPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(billFilterButt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dayBillFilBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(monthBillFillBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        Op3Pan.add(billFilterPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 570, 550));

        monthIncomePan.setBackground(new java.awt.Color(153, 153, 255));

        calculateIncomePan.setBackground(new java.awt.Color(102, 102, 102));
        calculateIncomePan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        displayPan.setBackground(new java.awt.Color(255, 255, 255));

        line1LB.setFont(new java.awt.Font("Segoe UI Black", 3, 16)); // NOI18N
        line1LB.setText("            Tính toán doanh thu theo tháng");

        line2LB.setFont(new java.awt.Font("Segoe UI Black", 3, 16)); // NOI18N

        javax.swing.GroupLayout displayPanLayout = new javax.swing.GroupLayout(displayPan);
        displayPan.setLayout(displayPanLayout);
        displayPanLayout.setHorizontalGroup(
            displayPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(displayPanLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(displayPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(line2LB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(line1LB, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        displayPanLayout.setVerticalGroup(
            displayPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(displayPanLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(line1LB, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(line2LB, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        calculateIncomePan.add(displayPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 160));

        calculatePan.setBackground(new java.awt.Color(204, 204, 204));

        calculateMonthBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        calculateMonthBox.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        calculateMonthBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateMonthBoxActionPerformed(evt);
            }
        });

        calculateButt.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Price list.png")); // NOI18N
        calculateButt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        calculateButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateButtActionPerformed(evt);
            }
        });

        refreshCalculateB.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\Hinh\\Refresh.png")); // NOI18N
        refreshCalculateB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshCalculateBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout calculatePanLayout = new javax.swing.GroupLayout(calculatePan);
        calculatePan.setLayout(calculatePanLayout);
        calculatePanLayout.setHorizontalGroup(
            calculatePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(calculatePanLayout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(calculateMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addGroup(calculatePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(refreshCalculateB, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(calculateButt, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(83, Short.MAX_VALUE))
        );
        calculatePanLayout.setVerticalGroup(
            calculatePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(calculatePanLayout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addGroup(calculatePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(calculateButt, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(calculateMonthBox, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(refreshCalculateB, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(116, Short.MAX_VALUE))
        );

        calculateIncomePan.add(calculatePan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 430, 310));

        javax.swing.GroupLayout monthIncomePanLayout = new javax.swing.GroupLayout(monthIncomePan);
        monthIncomePan.setLayout(monthIncomePanLayout);
        monthIncomePanLayout.setHorizontalGroup(
            monthIncomePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(monthIncomePanLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(calculateIncomePan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );
        monthIncomePanLayout.setVerticalGroup(
            monthIncomePanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(monthIncomePanLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(calculateIncomePan, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        Op3Pan.add(monthIncomePan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 570, 550));

        billListPan.setBackground(new java.awt.Color(153, 255, 153));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable3.setEnabled(false);
        jScrollPane4.setViewportView(jTable3);

        javax.swing.GroupLayout billListPanLayout = new javax.swing.GroupLayout(billListPan);
        billListPan.setLayout(billListPanLayout);
        billListPanLayout.setHorizontalGroup(
            billListPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 570, Short.MAX_VALUE)
        );
        billListPanLayout.setVerticalGroup(
            billListPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billListPanLayout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 100, Short.MAX_VALUE))
        );

        Op3Pan.add(billListPan, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 570, 550));

        getContentPane().add(Op3Pan, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 750, 550));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\NTHie\\OneDrive\\Pictures\\Saved Pictures\\pexels-no-name-.jpg")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void customersManageBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customersManageBActionPerformed
        // TODO add your handling code here:
        Op1Pan.setVisible(false);
        Op2Pan.setVisible(true);
        Op3Pan.setVisible(false);
        addCusPan.setVisible(false);
        deleteCusPan.setVisible(false);
        fixCusInfoPan.setVisible(false);
        cusListPanel.setVisible(false);
    }//GEN-LAST:event_customersManageBActionPerformed

    private void billManageButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billManageButtActionPerformed
        // TODO add your handling code here:
        Op1Pan.setVisible(false);
        Op2Pan.setVisible(false);
        Op3Pan.setVisible(true);
        addBillPan.setVisible(false);
        deleteBillPan.setVisible(false);
        billFilterPan.setVisible(false);
        monthIncomePan.setVisible(false);
        billListPan.setVisible(false);
    }//GEN-LAST:event_billManageButtActionPerformed

    private void roomManageButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomManageButtActionPerformed
        // TODO add your handling code here:
        Op1Pan.setVisible(true);
        Op2Pan.setVisible(false);
        Op3Pan.setVisible(false);
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(false);
        updateReturnDatePan.setVisible(false);
        updateReRoomPan.setVisible(false);
        deleteReRoomPan.setVisible(false);
        RoomFilterPan.setVisible(false);
    }//GEN-LAST:event_roomManageButtActionPerformed

    private void BookDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BookDateActionPerformed
        // TODO add your handling code here:
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(true);
        jPanel1.setVisible(false);
        DeleteRoomPan.setVisible(false);
        UpdateOrderPan.setVisible(false);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        DeleteRoomF.setText("Số phòng");
        UpdateRoomF.setText("Số phòng");
        UpdateDayBox.setSelectedItem("Ngày");
        UpdateMonthBox.setSelectedItem("Tháng");
        UpdateYearBox.setSelectedItem("Năm");
        RoomFilterPan.setVisible(false);
        roomListPan.setVisible(false);
    }//GEN-LAST:event_BookDateActionPerformed

    private void ReturnDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnDateActionPerformed
        // TODO add your handling code here:
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(false);
        updateReturnDatePan.setVisible(true);
        jPanel1.setVisible(true);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        RoomFilterPan.setVisible(false);
        deleteReRoomF.setText("Số phòng");
        updateRRfield.setText("Số phòng");
        roomListPan.setVisible(false);
    }//GEN-LAST:event_ReturnDateActionPerformed

    private void ChangeStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangeStatusActionPerformed
        // TODO add your handling code here:
        ChangeStatusPan.setVisible(true);
        DeleteRoomPan.setVisible(false);
        UpdateOrderPan.setVisible(false);
        updateOrderDate.setVisible(false);
        jPanel1.setVisible(false);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        jLabel4.setVisible(false);
        jLabel5.setVisible(false);
        FloorBox.setSelectedItem("Tầng");
        RoomBox.setSelectedItem("Số phòng");
        SecFloorBox.setSelectedItem("Số phòng");
        ThrdFloorBox.setSelectedItem("Số phòng");
        FourthFloorBox.setSelectedItem("Số phòng");
        FifthFloorBox.setSelectedItem("Số phòng");
        BlankRoomButt.setEnabled(false);
        OrderRoomButt.setEnabled(false);
        UsingRoomButt.setEnabled(false);
        FloorBox.setEnabled(true);
        SecFloorBox.setEnabled(true);
        ThrdFloorBox.setEnabled(true);
        FourthFloorBox.setEnabled(true);
        FifthFloorBox.setEnabled(true);
        RoomBox.setEnabled(true);
        RoomFilterPan.setVisible(false);
        roomListPan.setVisible(false);
    }//GEN-LAST:event_ChangeStatusActionPerformed

    private void FilterButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterButtActionPerformed
        // TODO add your handling code here:
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(false);
        updateReturnDatePan.setVisible(false);
        jPanel1.setVisible(false);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        RoomFilterPan.setVisible(true);
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        jLabel14.setVisible(false);
        jLabel15.setVisible(false);
        blankFilterB.setVisible(false);
        orderedFilterB.setVisible(false);
        usingFilterB.setVisible(false);
        doubleRoomB.setVisible(false);
        tripleRoomB.setVisible(false);
        fourRoomB.setVisible(false);
        orderDateFilterBox.setVisible(false);
        confirmOfilterB.setVisible(false);
        returnDateFilterBox.setVisible(false);
        confirmRfilterB.setVisible(false);
        roomStatusFilterB.setVisible(true);
        roomStoFilterB.setVisible(true);
        roomReturnFilterB.setVisible(true);
        roomOrderFilterB.setVisible(true);
        orderDateFilterBox.setSelectedItem("Ngày");
        returnDateFilterBox.setSelectedItem("Ngày");
        roomListPan.setVisible(false);
    }//GEN-LAST:event_FilterButtActionPerformed

    private void SecFloorBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SecFloorBoxActionPerformed
        // TODO add your handling code here:
        if(!SecFloorBox.getSelectedItem().toString().equals("Số phòng"))
        {
            jLabel5.setText(SecFloorBox.getSelectedItem().toString());
        }
    }//GEN-LAST:event_SecFloorBoxActionPerformed

    private void RoomBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoomBoxActionPerformed
        // TODO add your handling code here:
        if(!RoomBox.getSelectedItem().toString().equals("Số phòng"))
        {
            jLabel5.setText(RoomBox.getSelectedItem().toString());
        }
    }//GEN-LAST:event_RoomBoxActionPerformed

    private void FloorBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FloorBoxActionPerformed
        // TODO add your handling code here:
        if(!FloorBox.getSelectedItem().toString().equals("Tầng"))
        {   
            int i = Integer.parseInt(FloorBox.getSelectedItem().toString());
            if(i == 1)
            {
                RoomBox.setSelectedItem("Số phòng");
                RoomBox.setVisible(true);
                SecFloorBox.setVisible(false);
                ThrdFloorBox.setVisible(false);
                FourthFloorBox.setVisible(false);
                FifthFloorBox.setVisible(false);
                
            }
            if(i == 2)
            {
                SecFloorBox.setSelectedItem("Số phòng");
                SecFloorBox.setVisible(true);
                RoomBox.setVisible(false);
                ThrdFloorBox.setVisible(false);
                FourthFloorBox.setVisible(false);
                FifthFloorBox.setVisible(false);
                
            }
            if(i == 3)
            {
                ThrdFloorBox.setSelectedItem("Số phòng");
                ThrdFloorBox.setVisible(true);
                SecFloorBox.setVisible(false);
                RoomBox.setVisible(false);
                FourthFloorBox.setVisible(false);
                FifthFloorBox.setVisible(false);
                
            }
            if(i == 4)
            {
                FourthFloorBox.setSelectedItem("Số phòng");
                FourthFloorBox.setVisible(true);
                SecFloorBox.setVisible(false);
                ThrdFloorBox.setVisible(false);
                RoomBox.setVisible(false);
                FifthFloorBox.setVisible(false);
                
            }
            if(i == 5)
            {
                FifthFloorBox.setSelectedItem("Số phòng");
                FifthFloorBox.setVisible(true);
                SecFloorBox.setVisible(false);
                ThrdFloorBox.setVisible(false);
                FourthFloorBox.setVisible(false);
                RoomBox.setVisible(false);
                
            }
        }
    }//GEN-LAST:event_FloorBoxActionPerformed

    private void ConfirmButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmButtActionPerformed
        // TODO add your handling code here:
        if(!FloorBox.getSelectedItem().toString().equals("Tầng"))
        {   
            int i = Integer.parseInt(FloorBox.getSelectedItem().toString());
            switch (i)
            {
                case 1:
                    if(RoomBox.getSelectedItem().toString().equals("Số phòng"))
                    {
                        JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!","Thông báo!", HEIGHT);
                    }
                    else {
                        roomNum = Integer.parseInt(RoomBox.getSelectedItem().toString())-101; 
                        jLabel5.setVisible(true);
                        jLabel4.setVisible(true);
                        BlankRoomButt.setVisible(true);
                        OrderRoomButt.setVisible(true);
                        UsingRoomButt.setVisible(true);
                        RefreshButt.setVisible(true);
                        BlankRoomButt.setEnabled(true);
                        OrderRoomButt.setEnabled(true);
                        UsingRoomButt.setEnabled(true);
                    }
                    break;
                case 2:
                    if (SecFloorBox.getSelectedItem().toString().equals("Số phòng")) {
                        JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!", "Thông báo!", HEIGHT);
                    }
                    else {
                        roomNum = Integer.parseInt(SecFloorBox.getSelectedItem().toString())-191; 
                        jLabel5.setVisible(true);
                        jLabel4.setVisible(true);
                        BlankRoomButt.setVisible(true);
                        OrderRoomButt.setVisible(true);
                        UsingRoomButt.setVisible(true);
                        RefreshButt.setVisible(true);
                        BlankRoomButt.setEnabled(true);
                        OrderRoomButt.setEnabled(true);
                        UsingRoomButt.setEnabled(true);
                    }
                    break;
                case 3:
                    if (ThrdFloorBox.getSelectedItem().toString().equals("Số phòng")) {
                        JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!", "Thông báo!", HEIGHT);
                    }
                    else {
                        roomNum = Integer.parseInt(ThrdFloorBox.getSelectedItem().toString())-281; 
                        jLabel5.setVisible(true);
                        jLabel4.setVisible(true);
                        BlankRoomButt.setVisible(true);
                        OrderRoomButt.setVisible(true);
                        UsingRoomButt.setVisible(true);
                        RefreshButt.setVisible(true);
                        BlankRoomButt.setEnabled(true);
                        OrderRoomButt.setEnabled(true);
                        UsingRoomButt.setEnabled(true);
                    }
                    break;
                case 4:
                    if (FourthFloorBox.getSelectedItem().toString().equals("Số phòng")) {
                        JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!", "Thông báo!", HEIGHT);
                    }
                    else {
                        roomNum = Integer.parseInt(FourthFloorBox.getSelectedItem().toString())-371; 
                        jLabel5.setVisible(true);
                        jLabel4.setVisible(true);
                        BlankRoomButt.setVisible(true);
                        OrderRoomButt.setVisible(true);
                        UsingRoomButt.setVisible(true);
                        RefreshButt.setVisible(true);
                        BlankRoomButt.setEnabled(true);
                        OrderRoomButt.setEnabled(true);
                        UsingRoomButt.setEnabled(true);
                    }
                    break;
                case 5:
                    if (FifthFloorBox.getSelectedItem().toString().equals("Số phòng")) {
                        JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!", "Thông báo!", HEIGHT);
                    }
                    else {
                        roomNum = Integer.parseInt(FifthFloorBox.getSelectedItem().toString())-461; 
                        jLabel5.setVisible(true);
                        jLabel4.setVisible(true);
                        BlankRoomButt.setVisible(true);
                        OrderRoomButt.setVisible(true);
                        UsingRoomButt.setVisible(true);
                        RefreshButt.setVisible(true);
                        BlankRoomButt.setEnabled(true);
                        OrderRoomButt.setEnabled(true);
                        UsingRoomButt.setEnabled(true);
                    }
                    break;
                default:
                        break;
            }
        }
        else if(FloorBox.getSelectedItem().toString().equals("Tầng"))
        {
            JOptionPane.showMessageDialog(rootPane, "Thiếu thông tin!", "Thông báo!", HEIGHT);
        }
    }//GEN-LAST:event_ConfirmButtActionPerformed

    private void RefreshButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtActionPerformed
        // TODO add your handling code here:
        jLabel5.setVisible(false);
        FloorBox.setSelectedItem("Tầng");
        RoomBox.setSelectedItem("Số phòng");
        SecFloorBox.setSelectedItem("Số phòng");
        ThrdFloorBox.setSelectedItem("Số phòng");
        FourthFloorBox.setSelectedItem("Số phòng");
        FifthFloorBox.setSelectedItem("Số phòng");
        SecFloorBox.setEnabled(true);
        ThrdFloorBox.setEnabled(true);
        FourthFloorBox.setEnabled(true);
        FifthFloorBox.setEnabled(true);
        RoomBox.setEnabled(true);
        FloorBox.setEnabled(true);
    }//GEN-LAST:event_RefreshButtActionPerformed

    private void FourthFloorBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FourthFloorBoxActionPerformed
        // TODO add your handling code here:
        if(!FourthFloorBox.getSelectedItem().toString().equals("Số phòng"))
        {
            jLabel5.setText(FourthFloorBox.getSelectedItem().toString());
        }
    }//GEN-LAST:event_FourthFloorBoxActionPerformed

    private void ThrdFloorBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThrdFloorBoxActionPerformed
        // TODO add your handling code here:
        if(!ThrdFloorBox.getSelectedItem().toString().equals("Số phòng"))
        {
            jLabel5.setText(ThrdFloorBox.getSelectedItem().toString());
        }
    }//GEN-LAST:event_ThrdFloorBoxActionPerformed

    private void FifthFloorBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FifthFloorBoxActionPerformed
        // TODO add your handling code here:
        if(!FifthFloorBox.getSelectedItem().toString().equals("Số phòng"))
        {
            jLabel5.setText(FifthFloorBox.getSelectedItem().toString());
        }
    }//GEN-LAST:event_FifthFloorBoxActionPerformed

    private void OrderRoomButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderRoomButtActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        try {
            QuanLiPhong.cus_trangThai(listdata,roomNum, JSON_PATH_READ, CSV_PATH_WRITE,"da dat truoc");
            JOptionPane.showMessageDialog(rootPane, "Bạn đã thay đổi trạng thái phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        BlankRoomButt.setEnabled(false);
        OrderRoomButt.setEnabled(false);
        UsingRoomButt.setEnabled(false);
        SecFloorBox.setEnabled(false);
        ThrdFloorBox.setEnabled(false);
        FourthFloorBox.setEnabled(false);
        FifthFloorBox.setEnabled(false);
        RoomBox.setEnabled(false);
        FloorBox.setEnabled(false);
    }//GEN-LAST:event_OrderRoomButtActionPerformed

    private void UsingRoomButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsingRoomButtActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        try {
            QuanLiPhong.cus_trangThai(listdata,roomNum, JSON_PATH_READ, CSV_PATH_WRITE,"dang su dung");
            JOptionPane.showMessageDialog(rootPane, "Bạn đã thay đổi trạng thái phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        BlankRoomButt.setEnabled(false);
        OrderRoomButt.setEnabled(false);
        UsingRoomButt.setEnabled(false);
        SecFloorBox.setEnabled(false);
        ThrdFloorBox.setEnabled(false);
        FourthFloorBox.setEnabled(false);
        FifthFloorBox.setEnabled(false);
        RoomBox.setEnabled(false);
        FloorBox.setEnabled(false);
    }//GEN-LAST:event_UsingRoomButtActionPerformed

    private void BlankRoomButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BlankRoomButtActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        try {
            QuanLiPhong.cus_trangThai(listdata,roomNum, JSON_PATH_READ, CSV_PATH_WRITE,"trong");
            JOptionPane.showMessageDialog(rootPane, "Bạn đã thay đổi trạng thái phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        BlankRoomButt.setEnabled(false);
        OrderRoomButt.setEnabled(false);
        UsingRoomButt.setEnabled(false);
        SecFloorBox.setEnabled(false);
        ThrdFloorBox.setEnabled(false);
        FourthFloorBox.setEnabled(false);
        FifthFloorBox.setEnabled(false);
        RoomBox.setEnabled(false);
        FloorBox.setEnabled(false);
    }//GEN-LAST:event_BlankRoomButtActionPerformed

    private void UpdateRoomButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateRoomButtActionPerformed
        // TODO add your handling code here:
        UpdateOrderPan.setVisible(true);
    }//GEN-LAST:event_UpdateRoomButtActionPerformed

    private void DeleteRoomFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteRoomFActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_DeleteRoomFActionPerformed

    private void DeleteRoomFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DeleteRoomFFocusGained
        // TODO add your handling code here:
        if(DeleteRoomF.getText().equals("Số phòng"))
        {
            DeleteRoomF.setText(null);
        }
    }//GEN-LAST:event_DeleteRoomFFocusGained

    private void DeleteRoomFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DeleteRoomFFocusLost
        // TODO add your handling code here:
         if(DeleteRoomF.getText().equals(""))
        {
            DeleteRoomF.setText("Số phòng");
        }
    }//GEN-LAST:event_DeleteRoomFFocusLost

    private void DeleteRoomButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteRoomButtActionPerformed
        // TODO add your handling code here:
        DeleteRoomPan.setVisible(true);
    }//GEN-LAST:event_DeleteRoomButtActionPerformed

    private void ConfirmDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmDeleteActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(!DeleteRoomF.getText().isEmpty())
        {
            char ch[] = DeleteRoomF.getText().toCharArray();
            for(int i = 0; i < DeleteRoomF.getText().length(); i++)
            {
                if(!Character.isDigit(ch[i]))
                {
                    String oldText = NotifyLb.getText();
                    NotifyLb.setText("Số phòng không thể bao gồm chữ và ký tự đặc biệt !");
                    Timer timer = new Timer(1000, event -> {
                        NotifyLb.setText(oldText);
                    });
                    timer.setRepeats(false);
                    timer.start();
                    key = true;
                    break;
                }
            }
            if(key == false)
            {
                roomNum = Integer.parseInt(DeleteRoomF.getText());
                if (roomNum > 100 && roomNum < 511) {
                    //JOptionPane.showMessageDialog(rootPane, "Xóa ngày đặt phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                    QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                    for (int i = 0; i < listdata.size(); i++) {
                        if (Integer.parseInt(listdata.get(i).getMaP()) == roomNum) {
                            try {
                                QuanLiPhong.delete_ngayDatPhong(listdata, i, JSON_PATH_READ, CSV_PATH_WRITE);
                                JOptionPane.showMessageDialog(rootPane, "Xóa ngày đặt phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                                break;
                            } catch (IOException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Số phòng không hợp lệ!", "Thông báo!", HEIGHT);
                }
            }
        }
    }//GEN-LAST:event_ConfirmDeleteActionPerformed

    private void UpdateRoomFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateRoomFActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_UpdateRoomFActionPerformed

    private void ConfirmChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmChangeActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(UpdateDayBox.getSelectedItem().toString().equals("Ngày")||UpdateMonthBox.getSelectedItem().toString().equals("Tháng")||UpdateYearBox.getSelectedItem().toString().equals("Năm"))
        {
            String oldText = NotifyLb2.getText();
            NotifyLb2.setText("Thiếu thông tin ngày tháng năm!");
            Timer timer = new Timer(1000, event -> {
                NotifyLb2.setText(oldText);
            });
            timer.setRepeats(false);
            timer.start();
            key = true;
        }
        else if(!UpdateRoomF.getText().isEmpty())
        {
            char ch[] = UpdateRoomF.getText().toCharArray();
            for(int i = 0; i < UpdateRoomF.getText().length(); i++)
            {
                if(!Character.isDigit(ch[i]))
                {
                    String oldText = NotifyLb2.getText();
                    NotifyLb2.setText("Số phòng không thể bao gồm chữ và ký tự đặc biệt !");
                    Timer timer = new Timer(1000, event -> {
                        NotifyLb2.setText(oldText);
                    });
                    timer.setRepeats(false);
                    timer.start();
                    key = true;
                    break;
                }
            }
            if(key == false)
            {
                roomNum = Integer.parseInt(UpdateRoomF.getText());
                if (roomNum > 100 && roomNum < 511) {
                    //JOptionPane.showMessageDialog(rootPane, "Xóa ngày đặt phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                    QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                    for (int i = 0; i < listdata.size(); i++) {
                        if (Integer.parseInt(listdata.get(i).getMaP()) == roomNum) {
                            try {
                                QuanLiPhong.update_ngayDatPhong(listdata, i, JSON_PATH_READ, CSV_PATH_WRITE,Integer.parseInt(UpdateDayBox.getSelectedItem().toString()),Integer.parseInt(UpdateMonthBox.getSelectedItem().toString()),Integer.parseInt(UpdateYearBox.getSelectedItem().toString()));
                                JOptionPane.showMessageDialog(rootPane, "Bạn đã cập nhật thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                            } catch (IOException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } 
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Số phòng không hợp lệ!", "Thông báo!", HEIGHT);
                }
            }
        }
    }//GEN-LAST:event_ConfirmChangeActionPerformed

    private void UpdateDayBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateDayBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateDayBoxActionPerformed

    private void UpdateMonthBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateMonthBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateMonthBoxActionPerformed

    private void UpdateYearBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateYearBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateYearBoxActionPerformed

    private void UpdateRoomFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_UpdateRoomFFocusGained
        // TODO add your handling code here:
        if(UpdateRoomF.getText().equals("Số phòng"))
        {
            UpdateRoomF.setText(null);
        }
    }//GEN-LAST:event_UpdateRoomFFocusGained

    private void UpdateRoomFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_UpdateRoomFFocusLost
        // TODO add your handling code here:
        if(UpdateRoomF.getText().equals(""))
        {
            UpdateRoomF.setText("Số phòng");
        }
    }//GEN-LAST:event_UpdateRoomFFocusLost

    private void RefreshUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshUpdateActionPerformed
        // TODO add your handling code here:
        UpdateRoomF.setText("Số phòng");
        UpdateDayBox.setSelectedItem("Ngày");
        UpdateMonthBox.setSelectedItem("Tháng");
        UpdateYearBox.setSelectedItem("Năm");
    }//GEN-LAST:event_RefreshUpdateActionPerformed

    private void DeleteReturnDateButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteReturnDateButtActionPerformed
        // TODO add your handling code here:
        deleteReRoomPan.setVisible(true);
        updateReRoomPan.setVisible(false);
    }//GEN-LAST:event_DeleteReturnDateButtActionPerformed

    private void deleteReRoomFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteReRoomFFocusGained
        // TODO add your handling code here:
        if(deleteReRoomF.getText().equals("Số phòng"))
        {
            deleteReRoomF.setText(null);
        }
    }//GEN-LAST:event_deleteReRoomFFocusGained

    private void deleteReRoomFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteReRoomFFocusLost
        // TODO add your handling code here:
        if(deleteReRoomF.getText().equals(""))
        {
            deleteReRoomF.setText("Số phòng");
        }
    }//GEN-LAST:event_deleteReRoomFFocusLost

    private void confirmDeleteRRButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmDeleteRRButtActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(!deleteReRoomF.getText().isEmpty())
        {
            char ch[] = deleteReRoomF.getText().toCharArray();
            for(int i = 0; i < deleteReRoomF.getText().length(); i++)
            {
                if(!Character.isDigit(ch[i]))
                {
                    String oldText = NotifyLb3.getText();
                    NotifyLb3.setText("Số phòng không thể bao gồm chữ và ký tự đặc biệt !");
                    Timer timer = new Timer(1000, event -> {
                        NotifyLb3.setText(oldText);
                    });
                    timer.setRepeats(false);
                    timer.start();
                    key = true;
                    break;
                }
            }
            if(key == false)
            {
                roomNum = Integer.parseInt(deleteReRoomF.getText());
                if (roomNum > 100 && roomNum < 511) {
                    //JOptionPane.showMessageDialog(rootPane, "Xóa ngày đặt phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                    QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                    for (int i = 0; i < listdata.size(); i++) {
                        if (Integer.parseInt(listdata.get(i).getMaP()) == roomNum) {
                            try {
                                QuanLiPhong.delete_ngayTraPhong(listdata, i, JSON_PATH_READ, CSV_PATH_WRITE);
                                JOptionPane.showMessageDialog(rootPane, "Xóa ngày trả phòng thành công", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                                break;
                            } catch (IOException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    
                } else {
                    String oldText = NotifyLb3.getText();
                    NotifyLb3.setText("Số phòng không tồn tại!");
                    Timer timer = new Timer(1000, event -> {
                        NotifyLb3.setText(oldText);
                    });
                    timer.setRepeats(false);
                    timer.start();
                }
            }
        }
    }//GEN-LAST:event_confirmDeleteRRButtActionPerformed

    private void refreshUpdateButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshUpdateButtActionPerformed
        // TODO add your handling code here:
        uDateBox.setSelectedItem("Ngày");
        uMonthBox.setSelectedItem("Tháng");
        uYearBox.setSelectedItem("Năm");
        updateRRfield.setText("Số phòng");
    }//GEN-LAST:event_refreshUpdateButtActionPerformed

    private void uMonthBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uMonthBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uMonthBoxActionPerformed

    private void confirmUpdateButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmUpdateButtActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(uDateBox.getSelectedItem().toString().equals("Ngày")||uMonthBox.getSelectedItem().toString().equals("Tháng")||uYearBox.getSelectedItem().toString().equals("Năm"))
        {
            String oldText = NotifyLb4.getText();
            NotifyLb4.setText("Thiếu thông tin ngày tháng năm!");
            Timer timer = new Timer(1000, event -> {
                NotifyLb4.setText(oldText);
            });
            timer.setRepeats(false);
            timer.start();
            key = true;
        }
        else if(!updateRRfield.getText().isEmpty())
        {
            char ch[] = updateRRfield.getText().toCharArray();
            for(int i = 0; i < updateRRfield.getText().length(); i++)
            {
                if(!Character.isDigit(ch[i]))
                {
                    String oldText = NotifyLb4.getText();
                    NotifyLb4.setText("Số phòng không thể bao gồm chữ và ký tự đặc biệt !");
                    Timer timer = new Timer(1000, event -> {
                        NotifyLb4.setText(oldText);
                    });
                    timer.setRepeats(false);
                    timer.start();
                    key = true;
                    break;
                }
            }
            if(key == false)
            {
                roomNum = Integer.parseInt(updateRRfield.getText());
                if (roomNum > 100 && roomNum < 511) {
                    QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                    for (int i = 0; i < listdata.size(); i++) {
                        if (Integer.parseInt(listdata.get(i).getMaP()) == roomNum) {
                            try {
                                QuanLiPhong.update_ngayTraPhong(listdata, i, JSON_PATH_READ, CSV_PATH_WRITE,Integer.parseInt(uDateBox.getSelectedItem().toString()),Integer.parseInt(uMonthBox.getSelectedItem().toString()),Integer.parseInt(uYearBox.getSelectedItem().toString()));
                                JOptionPane.showMessageDialog(rootPane, "Bạn đã cập nhật thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                            } catch (IOException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } 
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Số phòng không hợp lệ!", "Thông báo!", HEIGHT);
                }
            }
        }
    }//GEN-LAST:event_confirmUpdateButtActionPerformed

    private void updateReturnDateButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateReturnDateButtActionPerformed
        // TODO add your handling code here:
        updateReRoomPan.setVisible(true);
        deleteReRoomPan.setVisible(false);
    }//GEN-LAST:event_updateReturnDateButtActionPerformed

    private void updateRRfieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_updateRRfieldFocusGained
        // TODO add your handling code here:
        if(updateRRfield.getText().equals("Số phòng"))
        {
            updateRRfield.setText(null);
        }
    }//GEN-LAST:event_updateRRfieldFocusGained

    private void updateRRfieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_updateRRfieldFocusLost
        // TODO add your handling code here:
        if(updateRRfield.getText().equals(""))
        {
            updateRRfield.setText("Số phòng");
        }
    }//GEN-LAST:event_updateRRfieldFocusLost

    private void roomStatusFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomStatusFilterBActionPerformed
        // TODO add your handling code here:
        jLabel12.setVisible(true);
        blankFilterB.setVisible(true);
        orderedFilterB.setVisible(true);
        usingFilterB.setVisible(true);
        roomStatusFilterB.setVisible(false);
    }//GEN-LAST:event_roomStatusFilterBActionPerformed

    private void roomReturnFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomReturnFilterBActionPerformed
        // TODO add your handling code here:
        jLabel15.setVisible(true);
        returnDateFilterBox.setVisible(true);
        confirmRfilterB.setVisible(true);
        roomReturnFilterB.setVisible(false);
    }//GEN-LAST:event_roomReturnFilterBActionPerformed

    private void returnDateFilterBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnDateFilterBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_returnDateFilterBoxActionPerformed

    private void roomStoFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomStoFilterBActionPerformed
        // TODO add your handling code here:
        jLabel13.setVisible(true);
        doubleRoomB.setVisible(true);
        tripleRoomB.setVisible(true);
        fourRoomB.setVisible(true);
        roomStoFilterB.setVisible(false);
    }//GEN-LAST:event_roomStoFilterBActionPerformed

    private void roomOrderFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomOrderFilterBActionPerformed
        // TODO add your handling code here:
        jLabel14.setVisible(true);
        orderDateFilterBox.setVisible(true);
        confirmOfilterB.setVisible(true);
        roomOrderFilterB.setVisible(false);
    }//GEN-LAST:event_roomOrderFilterBActionPerformed

    private void blankFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blankFilterBActionPerformed
        try {
            // TODO add your handling code here:
            QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
            QuanLiPhong.filter_trangThai(list_filter, listdata, 1);
            JOptionPane.showMessageDialog(rootPane, "Đã lọc trạng thái trống!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_blankFilterBActionPerformed

    private void orderedFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderedFilterBActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
            QuanLiPhong.filter_trangThai(list_filter, listdata, 2);
            JOptionPane.showMessageDialog(rootPane, "Đã lọc trạng thái đặt phòng!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_orderedFilterBActionPerformed

    private void usingFilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usingFilterBActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
            QuanLiPhong.filter_trangThai(list_filter, listdata, 3);
            JOptionPane.showMessageDialog(rootPane, "Đã lọc trạng thái đang sử dụng!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_usingFilterBActionPerformed

    private void doubleRoomBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doubleRoomBActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn lọc chi tiết?","Questions",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if(res == 0)
        {
            GUI2 gui2 = new GUI2();
            gui2.setVisible(true);
            gui2.setTextjLabel2("Phòng đôi");
        }
        else
        {
            try {
                QuanLiPhong.filter_sucChua(list_filter, listdata, list_filter_deatail, 1, 2, 0);
                JOptionPane.showMessageDialog(rootPane, "Lọc thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_doubleRoomBActionPerformed

    private void tripleRoomBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tripleRoomBActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn lọc chi tiết?","Questions",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if(res == 0)
        {
            GUI2 gui2 = new GUI2();
            gui2.setVisible(true);
            gui2.setTextjLabel2("Phòng ba");
        }
        else
        {
            try {
                QuanLiPhong.filter_sucChua(list_filter, listdata, list_filter_deatail, 2, 2, 0);
                JOptionPane.showMessageDialog(rootPane, "Lọc thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_tripleRoomBActionPerformed

    private void fourRoomBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fourRoomBActionPerformed
        // TODO add your handling code here:
        QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
        int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn lọc chi tiết?","Questions",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if(res == 0)
        {
            GUI2 gui2 = new GUI2();
            gui2.setVisible(true);
            gui2.setTextjLabel2("Phòng bốn");
        }
        else
        {
            try {
                QuanLiPhong.filter_sucChua(list_filter, listdata, list_filter_deatail, 3, 2, 0);
                JOptionPane.showMessageDialog(rootPane, "Lọc thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_fourRoomBActionPerformed

    private void confirmOfilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmOfilterBActionPerformed
        // TODO add your handling code here:
        if(orderDateFilterBox.getSelectedItem().toString().equals("Ngày"))
        {
            JOptionPane.showMessageDialog(rootPane, "Ngày không hợp lệ!","Thông báo!", HEIGHT);
        }
        else
        {
            try {
                QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                int day = Integer.parseInt(orderDateFilterBox.getSelectedItem().toString());
                QuanLiPhong.filter_locNgayDat(list_filter, listdata, day);
                JOptionPane.showMessageDialog(rootPane, "Lọc thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_confirmOfilterBActionPerformed

    private void confirmRfilterBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmRfilterBActionPerformed
        // TODO add your handling code here:
        if(returnDateFilterBox.getSelectedItem().toString().equals("Ngày"))
        {
            JOptionPane.showMessageDialog(rootPane, "Ngày không hợp lệ!","Thông báo!", HEIGHT);
        }
        else
        {
            try {
                QuanLiPhong.read_Json(JSON_PATH_READ, listdata);
                int day = Integer.parseInt(returnDateFilterBox.getSelectedItem().toString());
                QuanLiPhong.filter_locNgayTra(list_filter, listdata, day);
                JOptionPane.showMessageDialog(rootPane, "Lọc thành công!", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_confirmRfilterBActionPerformed

    private void deleteCusButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCusButtActionPerformed
        // TODO add your handling code here:
        addCusPan.setVisible(false);
        deleteCusPan.setVisible(true);
        fixCusInfoPan.setVisible(false);
        deleteCusField.setText("Nhập số phòng cần xóa KH");
        cusListPanel.setVisible(false);
    }//GEN-LAST:event_deleteCusButtActionPerformed

    private void checkButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkButtActionPerformed
        // TODO add your handling code here:
        if(cusNameField.getText().equals("Tên khách hàng")||phoneField.getText().equals("Số điện thoại")
                ||addressField.getText().equals("Địa chỉ"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO", HEIGHT);
        }
        else if(nameKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng tên!","THÔNG BÁO", HEIGHT);
        }
        else if(phoneKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng SĐT!","THÔNG BÁO", HEIGHT);
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Hợp lệ", "THÔNG BÁO", JOptionPane.INFORMATION_MESSAGE);
            jLabel19.setVisible(true);
            roomToAddField.setVisible(true);
            cusCodeField.setVisible(true);
            confirmCheckBox.setVisible(true);
            completeButt.setVisible(true);
            completeButt.setEnabled(false);
        }
    }//GEN-LAST:event_checkButtActionPerformed

    private void cusCodeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cusCodeFieldActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cusCodeFieldActionPerformed

    private void addCusButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCusButtActionPerformed
        // TODO add your handling code here:
        addCusPan.setVisible(true);
        jLabel19.setVisible(false);
        roomToAddField.setVisible(false);
        cusCodeField.setVisible(false);
        confirmCheckBox.setVisible(false);
        completeButt.setVisible(false);
        deleteCusPan.setVisible(false);
        fixCusInfoPan.setVisible(false);
        cusListPanel.setVisible(false);
        cusNameField.setText("Tên khách hàng");
        phoneField.setText("Số điện thoại");
        addressField.setText("Địa chỉ");
        roomToAddField.setText("Thêm KH vào phòng (101-510)");
        cusCodeField.setText("Đặt mã KH");
        confirmCheckBox.setSelected(false);
    }//GEN-LAST:event_addCusButtActionPerformed

    private void roomToAddFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomToAddFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roomToAddFieldActionPerformed

    private void addressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressFieldActionPerformed

    private void cusNameFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cusNameFieldFocusGained
        // TODO add your handling code here:
        if(cusNameField.getText().equals("Tên khách hàng"))
        {
            cusNameField.setText(null);
        }
    }//GEN-LAST:event_cusNameFieldFocusGained

    private void cusNameFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cusNameFieldFocusLost
        // TODO add your handling code here:
        if(cusNameField.getText().equals(""))
        {
            cusNameField.setText("Tên khách hàng");
        }
        else
        {
            char ch[] = cusNameField.getText().toCharArray();
            for(int i = 0; i < cusNameField.getText().length(); i++)
            {
                if(Character.isLetter(ch[i])||Character.isWhitespace(ch[i]))
                {
                    if (i == cusNameField.getText().length() - 1) {
                        nameKey = false;
                    }
                }
                else
                {
                    nameKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_cusNameFieldFocusLost

    private void phoneFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneFieldFocusGained
        // TODO add your handling code here:
        if(phoneField.getText().equals("Số điện thoại"))
        {
            phoneField.setText(null);
        }
    }//GEN-LAST:event_phoneFieldFocusGained

    private void phoneFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneFieldFocusLost
        // TODO add your handling code here:
        if(phoneField.getText().equals(""))
        {
            phoneField.setText("Số điện thoại");
        }
        else
        {
            char ch[] = phoneField.getText().toCharArray();
            for(int i = 0; i < phoneField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if (i == phoneField.getText().length() - 1) {
                        phoneKey = false;
                    }
                }
                else
                {
                    phoneKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_phoneFieldFocusLost

    private void addressFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addressFieldFocusGained
        // TODO add your handling code here:
        if(addressField.getText().equals("Địa chỉ"))
        {
            addressField.setText(null);
        }
    }//GEN-LAST:event_addressFieldFocusGained

    private void addressFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addressFieldFocusLost
        // TODO add your handling code here:
        if(addressField.getText().equals(""))
        {
            addressField.setText("Địa chỉ");
        }  
    }//GEN-LAST:event_addressFieldFocusLost

    private void roomToAddFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_roomToAddFieldFocusGained
        // TODO add your handling code here:
        roomToAddField.setEditable(true);
        if(roomToAddField.getText().equals("Thêm KH vào phòng (101-510)"))
        {
            roomToAddField.setText(null);
        }
    }//GEN-LAST:event_roomToAddFieldFocusGained

    private void roomToAddFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_roomToAddFieldFocusLost
        // TODO add your handling code here:
        if(roomToAddField.getText().equals(""))
        {
            roomToAddField.setText("Thêm KH vào phòng (101-510)");
        }
        else
        {
            char ch[] = roomToAddField.getText().toCharArray();
            for(int i = 0; i < roomToAddField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if(i == roomToAddField.getText().length() - 1){
                        int x = Integer.parseInt(roomToAddField.getText());
                        if(x >= 101 && x <= 510)
                        {
                            roomKey = false;
                        }
                        else
                        {
                            roomKey = true;
                        }
                    }
                }
                else
                {
                    roomKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_roomToAddFieldFocusLost

    private void cusCodeFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cusCodeFieldFocusGained
        // TODO add your handling code here:
        if(cusCodeField.getText().equals("Đặt mã KH"))
        {
            cusCodeField.setText(null);
        }
    }//GEN-LAST:event_cusCodeFieldFocusGained

    private void cusCodeFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cusCodeFieldFocusLost
        // TODO add your handling code here:
        if(cusCodeField.getText().equals(""))
        {
            cusCodeField.setText("Đặt mã KH");
        }
        else
        {
            char ch[] = cusCodeField.getText().toCharArray();
            for(int i = 0; i < cusCodeField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if(i == cusCodeField.getText().length() - 1){
                        roomCodeKey = false;
                    }
                    else
                    {
                        roomCodeKey = true;
                    }
                }
                else
                {
                    roomCodeKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_cusCodeFieldFocusLost

    private void cusNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cusNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cusNameFieldActionPerformed

    private void confirmCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmCheckBoxActionPerformed
        // TODO add your handling code here:
        if(confirmCheckBox.isSelected())
        {
            completeButt.setEnabled(true);
        }
        else
        {
            completeButt.setEnabled(false);
        }
    }//GEN-LAST:event_confirmCheckBoxActionPerformed

    private void completeButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completeButtActionPerformed
        // TODO add your handling code here:
        if(cusNameField.getText().equals("Tên khách hàng")||phoneField.getText().equals("Số điện thoại")
                ||addressField.getText().equals("Địa chỉ")||roomToAddField.getText().equals("Thêm KH vào phòng (101-510)")
                ||cusCodeField.getText().equals("Đặt mã KH"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO", HEIGHT);
        }
        else if(nameKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng tên!","THÔNG BÁO", HEIGHT);
        }
        else if(phoneKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng SĐT!","THÔNG BÁO", HEIGHT);
        }
        else if(roomKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng phòng!","THÔNG BÁO", HEIGHT);

        }
        else if(roomCodeKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn đã nhập sai định dạng mã phòng!","THÔNG BÁO", HEIGHT);
        }
        else
        {
            try {
                QuanLiKhachHang.add_KH(JSON_PATH_READ_KH, list_Phong, list_KH, Integer.parseInt(roomToAddField.getText()), cusCodeField.getText(), cusNameField.getText(), phoneField.getText(), addressField.getText());
                JOptionPane.showMessageDialog(rootPane, "THÊM KHÁCH HÀNG THÀNH CÔNG!","Thông báo!", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_completeButtActionPerformed

    private void roomListButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomListButtActionPerformed
        // TODO add your handling code here:
        roomListPan.setVisible(true);
        ChangeStatusPan.setVisible(false);
        updateOrderDate.setVisible(false);
        updateReturnDatePan.setVisible(false);
        jPanel1.setVisible(false);
        deleteReRoomPan.setVisible(false);
        updateReRoomPan.setVisible(false);
        RoomFilterPan.setVisible(false);
        try {
            if(roomTableKey == 1)
            {
                //jTable1.setModel(new DefaultTableModel((Object[][])null,null));
                csv_data.setRowCount(0);
            }
            showTable();
            roomTableKey = 1;
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_roomListButtActionPerformed

    private void deleteCusFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCusFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteCusFieldActionPerformed

    private void deleteCusFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteCusFieldFocusGained
        // TODO add your handling code here:
        if(deleteCusField.getText().equals("Nhập số phòng cần xóa KH"))
        {
            deleteCusField.setText(null);
        }
    }//GEN-LAST:event_deleteCusFieldFocusGained

    private void deleteCusFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteCusFieldFocusLost
        // TODO add your handling code here:
        if(deleteCusField.getText().equals(""))
        {
            deleteCusField.setText("Nhập số phòng cần xóa KH");
        }
        else
        {
            char ch[] = deleteCusField.getText().toCharArray();
            for(int i = 0; i < deleteCusField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    int x = Integer.parseInt(deleteCusField.getText());
                    if (x >= 101 && x <= 510) {
                        deleteCusKey = false;
                    }
                    else
                    {
                        deleteCusKey = true;
                    }
                }
                else
                {
                    deleteCusKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_deleteCusFieldFocusLost

    private void confirmDeleteCusBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmDeleteCusBActionPerformed
        // TODO add your handling code here:
        if(deleteCusField.getText().equals("Nhập số phòng cần xóa KH"))
        {
            JOptionPane.showMessageDialog(rootPane, "CHƯA NHẬP THÔNG TIN", "THÔNG BÁO!", HEIGHT);
        }
        else if (deleteCusKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "SỐ PHÒNG KHÔNG HỢP LỆ", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                int x = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa ?", "Question",JOptionPane.YES_NO_OPTION, HEIGHT);
                if(x == 0)
                {
                int i = Integer.parseInt(deleteCusField.getText());
                QuanLiKhachHang.delete_KH(i);
                JOptionPane.showMessageDialog(rootPane, "Xóa KH thành công!", "THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_confirmDeleteCusBActionPerformed

    private void fixCusPhoneFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fixCusPhoneFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fixCusPhoneFActionPerformed

    private void fixCusCodeFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusCodeFFocusGained
        // TODO add your handling code here:
        if(fixCusCodeF.getText().equals("Nhập mã KH cần sửa"))
        {
            fixCusCodeF.setText(null);
        }
    }//GEN-LAST:event_fixCusCodeFFocusGained

    private void fixCusCodeFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusCodeFFocusLost
        // TODO add your handling code here:
        if(fixCusCodeF.getText().equals(""))
        {
            fixCusCodeF.setText("Nhập mã KH cần sửa");
        } 
        else
        {
            char ch[] = fixCusCodeF.getText().toCharArray();
            for(int i = 0; i < fixCusCodeF.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if(i == fixCusCodeF.getText().length() - 1){
                        fixCusCodeKey = false;
                    }
                    else
                    {
                        fixCusCodeKey = true;
                    }
                }
                else
                {
                    fixCusCodeKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_fixCusCodeFFocusLost

    private void fixCusNameFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusNameFFocusGained
        // TODO add your handling code here:
        if(fixCusNameF.getText().equals("Nhập lại tên"))
        {
            fixCusNameF.setText(null);
        }
    }//GEN-LAST:event_fixCusNameFFocusGained

    private void fixCusNameFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusNameFFocusLost
        // TODO add your handling code here:
        if(fixCusNameF.getText().equals(""))
        {
            fixCusNameF.setText("Nhập lại tên");
        }
        else
        {
            char ch[] = fixCusNameF.getText().toCharArray();
            for(int i = 0; i < fixCusNameF.getText().length(); i++)
            {
                if(Character.isLetter(ch[i])||Character.isWhitespace(ch[i]))
                {
                    if (i == fixCusNameF.getText().length() - 1) {
                        fixCusNameKey = false;
                    }
                }
                else
                {
                    fixCusNameKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_fixCusNameFFocusLost

    private void fixCusAdFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusAdFFocusGained
        // TODO add your handling code here:
        if(fixCusAdF.getText().equals("Nhập lại địa chỉ"))
        {
            fixCusAdF.setText(null);
        }
    }//GEN-LAST:event_fixCusAdFFocusGained

    private void fixCusAdFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusAdFFocusLost
        // TODO add your handling code here:
        if(fixCusAdF.getText().equals(""))
        {
            fixCusAdF.setText("Nhập lại địa chỉ");
        }
    }//GEN-LAST:event_fixCusAdFFocusLost

    private void fixCusPhoneFFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusPhoneFFocusGained
        // TODO add your handling code here:
        if(fixCusPhoneF.getText().equals("Nhập lại SĐT"))
        {
            fixCusPhoneF.setText(null);
        }
    }//GEN-LAST:event_fixCusPhoneFFocusGained

    private void fixCusPhoneFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fixCusPhoneFFocusLost
        // TODO add your handling code here:
         if(fixCusPhoneF.getText().equals(""))
        {
            fixCusPhoneF.setText("Nhập lại SĐT");
        }
        else
        {
            char ch[] = fixCusPhoneF.getText().toCharArray();
            for(int i = 0; i < fixCusPhoneF.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if (i == fixCusPhoneF.getText().length() - 1) {
                        fixCusPhoneKey = false;
                    }
                }
                else
                {
                    fixCusPhoneKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_fixCusPhoneFFocusLost

    private void fixCusCodeFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fixCusCodeFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fixCusCodeFActionPerformed

    private void findButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findButtActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(fixCusCodeF.getText().equals("Nhập mã KH cần sửa"))
        {
            JOptionPane.showMessageDialog(rootPane, "CHƯA NHẬP THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else if(fixCusCodeKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "SAI ĐỊNH DẠNG MÃ KH!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
        QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
        for (int i = 0; i < list_Phong.size(); i++) {
            if (list_Phong.get(i).getKH().getMaKH() != null) {
                if (list_Phong.get(i).getKH().getMaKH().compareTo(fixCusCodeF.getText().trim()) == 0) {
                    fixCusAdF.setEnabled(true);
                    fixCusPhoneF.setEnabled(true);
                    fixCusNameF.setEnabled(true);
                    jButton1.setVisible(true);
                    jButton2.setVisible(true);
                    jButton3.setVisible(true);
                    JOptionPane.showMessageDialog(rootPane, "Hợp lệ", "Thông báo!", JOptionPane.INFORMATION_MESSAGE);
                    key = false;
                    break;
                }
                else
                {
                    key = true;
                }
            }
        }
        if(key == true)
        {
            JOptionPane.showMessageDialog(rootPane, "KHÔNG TÌM THẤY KH!", "THÔNG BÁO!", HEIGHT);
            fixCusAdF.setEnabled(false);
            fixCusPhoneF.setEnabled(false);
            fixCusNameF.setEnabled(false);
            jButton1.setVisible(false);
            jButton2.setVisible(false);
            jButton3.setVisible(false);
        }
        }
    }//GEN-LAST:event_findButtActionPerformed

    private void fixCusButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fixCusButtActionPerformed
        // TODO add your handling code here:
        fixCusCodeF.setText("Nhập mã KH cần sửa");
        addCusPan.setVisible(false);
        deleteCusPan.setVisible(false);
        fixCusInfoPan.setVisible(true);
        fixCusAdF.setEnabled(false);
        fixCusPhoneF.setEnabled(false);
        fixCusNameF.setEnabled(false);
        jButton1.setVisible(false);
        jButton2.setVisible(false);
        jButton3.setVisible(false);
        fixCusNameF.setText("Nhập lại tên");
        fixCusAdF.setText("Nhập lại địa chỉ");
        fixCusPhoneF.setText("Nhập lại SĐT");
        cusListPanel.setVisible(false);
    }//GEN-LAST:event_fixCusButtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if(fixCusNameF.getText().equals("Nhập lại tên"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else if (fixCusNameKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "SAI ĐỊNH DẠNG TÊN!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
                QuanLiKhachHang.set_list_KH(JSON_PATH_READ_KH, list_KH);
                int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn thay đổi ?", "Question", JOptionPane.YES_NO_OPTION);
                if(res == 0)
                {
                QuanLiKhachHang.cus_inforKH(fixCusCodeF.getText(), 3, null, null, fixCusNameF.getText());
                JOptionPane.showMessageDialog(rootPane,"Thay đổi thành công","THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if(fixCusAdF.getText().equals("Nhập lại địa chỉ"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
                QuanLiKhachHang.set_list_KH(JSON_PATH_READ_KH, list_KH);
                int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn thay đổi ?", "Question", JOptionPane.YES_NO_OPTION);
                if(res == 0)
                {
                QuanLiKhachHang.cus_inforKH(fixCusCodeF.getText(), 2, null, fixCusAdF.getText(), null);
                JOptionPane.showMessageDialog(rootPane,"Thay đổi thành công","THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if(fixCusPhoneF.getText().equals("Nhập lại SĐT"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
                QuanLiKhachHang.set_list_KH(JSON_PATH_READ_KH, list_KH);
                int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn thay đổi ?", "Question", JOptionPane.YES_NO_OPTION);
                if(res == 0)
                {
                QuanLiKhachHang.cus_inforKH(fixCusCodeF.getText(), 1, fixCusPhoneF.getText(), null, null);
                JOptionPane.showMessageDialog(rootPane,"Thay đổi thành công","THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void customersListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customersListActionPerformed
        // TODO add your handling code here:
        deleteCusPan.setVisible(false);
        addCusPan.setVisible(false);
        fixCusInfoPan.setVisible(false);
        cusListPanel.setVisible(true);
        try {
            if(cusTableKey == 1)
            {
                //jTable1.setModel(new DefaultTableModel((Object[][])null,null));
                cusListData.setRowCount(0);
            }
            showCusList();
            cusTableKey = 1;
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_customersListActionPerformed

    private void jLabel21MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseEntered
        // TODO add your handling code here:
        jLabel21.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_jLabel21MouseEntered

    private void jLabel21MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseExited
        // TODO add your handling code here:
        jLabel21.setForeground(null);
    }//GEN-LAST:event_jLabel21MouseExited

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
        roomFilterFrame newFrame = new roomFilterFrame();
        newFrame.setVisible(true);
    }//GEN-LAST:event_jLabel21MouseClicked

    private void addBillFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addBillFieldFocusGained
        // TODO add your handling code here:
        if(addBillField.getText().equals("Nhập mã khách hàng muốn thêm hoá đơn"))
        {
            addBillField.setText(null);
        }
    }//GEN-LAST:event_addBillFieldFocusGained

    private void addBillFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addBillFieldFocusLost
        // TODO add your handling code here:
        if(addBillField.getText().equals(""))
        {
            addBillField.setText("Nhập mã khách hàng muốn thêm hoá đơn");
        } 
        else
        {
            char ch[] = addBillField.getText().toCharArray();
            for(int i = 0; i < addBillField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if(i == addBillField.getText().length() - 1){
                        addBillKey = false;
                    }
                    else
                    {
                        addBillKey = true;
                    }
                }
                else
                {
                    addBillKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_addBillFieldFocusLost

    private void searchCusBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchCusBActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(addBillField.getText().equals("Nhập mã khách hàng muốn thêm hoá đơn"))
        {
            JOptionPane.showMessageDialog(rootPane, "CHƯA NHẬP THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else if(addBillKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "SAI ĐỊNH DẠNG MÃ KH!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
        QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
        for (int i = 0; i < list_Phong.size(); i++) {
            if (list_Phong.get(i).getKH().getMaKH() != null) {
                if (list_Phong.get(i).getKH().getMaKH().compareTo(addBillField.getText().trim()) == 0) {
                    int x = JOptionPane.showConfirmDialog(rootPane, "HỢP LỆ! Bạn chắc chắn thêm?", "THÔNG BÁO", JOptionPane.YES_NO_OPTION);
                    if(x == 0)
                    {
                        try {
                            QuanLiHoaDon.add_HD(addBillField.getText());
                            JOptionPane.showMessageDialog(rootPane, "Thêm hóa đơn thành công!", "THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IOException ex) {
                            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    key = false;
                    break;
                }
                else
                {
                    key = true;
                }
            }
        }
        if(key == true)
        {
            JOptionPane.showMessageDialog(rootPane, "KHÔNG TÌM THẤY KH! Vui lòng thêm khách hàng trước khi thêm hoá đơn.", "THÔNG BÁO!", HEIGHT);
        }
        }
    }//GEN-LAST:event_searchCusBActionPerformed

    private void addBillButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBillButtActionPerformed
        // TODO add your handling code here:
        addBillPan.setVisible(true);
        deleteBillPan.setVisible(false);
        billFilterPan.setVisible(false);
        billListPan.setVisible(false);
        monthIncomePan.setVisible(false);
        addBillField.setText("Nhập mã khách hàng muốn thêm hoá đơn");
    }//GEN-LAST:event_addBillButtActionPerformed

    private void deleteBillFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteBillFieldFocusGained
        // TODO add your handling code here:
        if(deleteBillField.getText().equals("Nhập mã KH muốn xóa hóa đơn"))
        {
            deleteBillField.setText(null);
        }
    }//GEN-LAST:event_deleteBillFieldFocusGained

    private void deleteBillFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteBillFieldFocusLost
        // TODO add your handling code here:
        if(deleteBillField.getText().equals(""))
        {
            deleteBillField.setText("Nhập mã KH muốn xóa hóa đơn");
        }
        else
        {
            char ch[] = deleteBillField.getText().toCharArray();
            for(int i = 0; i < deleteBillField.getText().length(); i++)
            {
                if(Character.isDigit(ch[i]))
                {
                    if(i == deleteBillField.getText().length() - 1){
                        deleteBillKey = false;
                    }
                    else
                    {
                        deleteBillKey = true;
                    }
                }
                else
                {
                    deleteBillKey = true;
                    break;
                }
            }
        }
    }//GEN-LAST:event_deleteBillFieldFocusLost

    private void deleteBillButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBillButtActionPerformed
        // TODO add your handling code here:
        deleteBillPan.setVisible(true);
        addBillPan.setVisible(false);
        billFilterPan.setVisible(false);
        monthIncomePan.setVisible(false);
        billListPan.setVisible(false);
        deleteBillField.setText("Nhập mã KH muốn xóa hóa đơn");
    }//GEN-LAST:event_deleteBillButtActionPerformed

    private void searchDeleteBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchDeleteBActionPerformed
        // TODO add your handling code here:
        boolean key = false;
        if(deleteBillField.getText().equals("Nhập mã KH muốn xóa hóa đơn"))
        {
            JOptionPane.showMessageDialog(rootPane, "CHƯA NHẬP THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else if(deleteBillKey == true)
        {
            JOptionPane.showMessageDialog(rootPane, "SAI ĐỊNH DẠNG MÃ KH!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
        QuanLiPhong.read_Json(JSON_PATH_READ_KH, list_Phong);
        for (int i = 0; i < list_Phong.size(); i++) {
            if (list_Phong.get(i).getKH().getMaKH() != null) {
                if (list_Phong.get(i).getKH().getMaKH().compareTo(deleteBillField.getText().trim()) == 0) {
                    int x = JOptionPane.showConfirmDialog(rootPane, "HỢP LỆ! Bạn chắc chắn xóa?", "THÔNG BÁO", JOptionPane.YES_NO_OPTION);
                    if(x == 0)
                    {
                        try {
                            QuanLiHoaDon.delete_HD(deleteBillField.getText());
                            JOptionPane.showMessageDialog(rootPane, "Xóa hóa đơn thành công!", "THÔNG BÁO!", JOptionPane.INFORMATION_MESSAGE);
                        } catch (IOException ex) {
                            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    key = false;
                    break;
                }
                else
                {
                    key = true;
                }
            }
        }
        if(key == true)
        {
            JOptionPane.showMessageDialog(rootPane, "KHÔNG TÌM THẤY KH! Vui lòng xem lại danh sách", "THÔNG BÁO!", HEIGHT);
        }
        }
    }//GEN-LAST:event_searchDeleteBActionPerformed

    private void dayBillFilBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayBillFilBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dayBillFilBoxActionPerformed

    private void billFilterButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billFilterButtActionPerformed
        if(dayBillFilBox.getSelectedItem().toString().equals("Ngày")||monthBillFillBox.getSelectedItem().toString().equals("Tháng"))
        {
            JOptionPane.showMessageDialog(rootPane, "THIẾU THÔNG TIN!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                QuanLiHoaDon.set_list_HD(JSON_PATH_READ, JSON_PATH_WRITE_HD, list_Hoadon);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
            list_filter_HD.clear();
            DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            System.out.println("Nhập ngày thanh toán cần lọc: ");
            String day_month = dayBillFilBox.getSelectedItem().toString() + " " + monthBillFillBox.getSelectedItem().toString();
            String[] day_month_split = day_month.split(" ");
            for (Hoa_don e : list_Hoadon) {
                if (e.getNgayThanhToan() != null) {
                    String[] date_df = df.format(e.getNgayThanhToan()).split("-");
                    String date1 = "";
                    for (int i = 0; i < day_month_split.length - 1; i++) {

                        if (Integer.parseInt(date_df[i + 1]) == Integer.parseInt(day_month_split[i + 1])) {
                            if (Integer.parseInt(date_df[i]) == Integer.parseInt(day_month_split[i])) {
                                list_filter_HD.add(e);
                                break;
                            }
                        }

                    }
                }
            }
            if(list_filter_HD.size() == 0)
            {
                QuanLiHoaDon.write_csv_HD(CSV_Filter_HD, list_filter_HD);
                list_Hoadon.clear();
                JOptionPane.showMessageDialog(rootPane, "KHÔNG TỒN TẠI NGÀY THÁNG!", "THÔNG BÁO", HEIGHT);
            }
            else
            {
                QuanLiHoaDon.write_csv_HD(CSV_Filter_HD, list_filter_HD);
                list_Hoadon.clear();
                int x = JOptionPane.showConfirmDialog(rootPane, "Lọc thành công! Bạn có muốn xem danh sách?", "THÔNG BÁO!", JOptionPane.YES_NO_OPTION);
                if (x == 0) {
                    try {
                        jTable2.setVisible(true);
                        if (billFilterKey == 1) {
                            //jTable1.setModel(new DefaultTableModel((Object[][])null,null));
                            billFilterData.setRowCount(0);
                        }
                        showBillFilter();
                        billFilterKey = 1;
                    } catch (IOException ex) {
                        Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }//GEN-LAST:event_billFilterButtActionPerformed

    private void filterBillButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterBillButtActionPerformed
        // TODO add your handling code here:
        addBillPan.setVisible(false);
        deleteBillPan.setVisible(false);
        billFilterPan.setVisible(true);
        dayBillFilBox.setSelectedItem("Ngày");
        monthBillFillBox.setSelectedItem("Tháng");
        billListPan.setVisible(false);
        jTable2.setVisible(false);
    }//GEN-LAST:event_filterBillButtActionPerformed

    private void incomeBymonthBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incomeBymonthBActionPerformed
        // TODO add your handling code here:
        addBillPan.setVisible(false);
        deleteBillPan.setVisible(false);
        billFilterPan.setVisible(false);
        monthIncomePan.setVisible(true);
        billListPan.setVisible(false);
        calculateMonthBox.setSelectedItem("Tháng");
        line1LB.setText("            Tính toán doanh thu theo tháng");
        line2LB.setText("");
    }//GEN-LAST:event_incomeBymonthBActionPerformed

    private void refreshCalculateBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshCalculateBActionPerformed
        // TODO add your handling code here:
        line1LB.setText("            Tính toán doanh thu theo tháng");
        line2LB.setText("");
        calculateMonthBox.setSelectedItem("Tháng");
    }//GEN-LAST:event_refreshCalculateBActionPerformed

    private void calculateMonthBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateMonthBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calculateMonthBoxActionPerformed

    private void calculateButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateButtActionPerformed
        // TODO add your handling code here:
        if(calculateMonthBox.getSelectedItem().equals("Tháng"))
        {
            JOptionPane.showMessageDialog(rootPane, "Bạn chưa chọn tháng!", "THÔNG BÁO!", HEIGHT);
        }
        else
        {
            try {
                QuanLiHoaDon.set_list_HD(JSON_PATH_READ, JSON_PATH_WRITE_HD, list_Hoadon);
                int month = 0;
                boolean validMonth = false;
                do {
                    while (validMonth != true) {
                        try {
                            System.out.println("Nhập tháng tính doanh thu");
                            month = Integer.parseInt(calculateMonthBox.getSelectedItem().toString());
                            validMonth = true;
                            double doanh_thu = 0;
                            for (Hoa_don e : list_Hoadon) {
                                if (e.getNgayThanhToan() != null) {
                                    if (e.getNgayThanhToan().getMonthValue() == month) {
                                        doanh_thu = doanh_thu + e.getGiaTien();
                                    }
                                }
                            }
                            if (month > 0 && month < 13) {
                                //System.out.printf("Doanh thu của khách sạn tháng %d là %.2f\n", month, doanh_thu);
                                line1LB.setText("Tháng : " + month);
                                line2LB.setText("Doanh thu của khách sạn :  " + (int)doanh_thu + " VND");
                            }
                            
                        } catch (InputMismatchException e) {
                            System.out.println("Định dạng không hợp lệ ! Vui lòng nhập lại. ");
                            //sc.nextLine();
                        }
                    }
                    if (month < 1 || month > 12) {
                        System.out.println("Không tồn tại tháng " + month);
                        validMonth = false;
                    }
                    
                } while (month < 1 || month > 12);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_calculateButtActionPerformed

    private void billListButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billListButtActionPerformed
        // TODO add your handling code here:
        addBillPan.setVisible(false);
        deleteBillPan.setVisible(false);
        billFilterPan.setVisible(false);
        monthIncomePan.setVisible(false);
        billListPan.setVisible(true);
        try {
            if(billListKey == 1)
            {
                //jTable1.setModel(new DefaultTableModel((Object[][])null,null));
                billListData.setRowCount(0);
            }
            showBillList();
            billListKey = 1;
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_billListButtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BlankRoomButt;
    private javax.swing.JButton BookDate;
    private javax.swing.JButton ChangeStatus;
    private javax.swing.JPanel ChangeStatusPan;
    private javax.swing.JButton ConfirmButt;
    private javax.swing.JButton ConfirmChange;
    private javax.swing.JButton ConfirmDelete;
    private javax.swing.JButton DeleteReturnDateButt;
    private javax.swing.JButton DeleteRoomButt;
    private javax.swing.JTextField DeleteRoomF;
    private javax.swing.JPanel DeleteRoomPan;
    private javax.swing.JComboBox<String> FifthFloorBox;
    private javax.swing.JButton FilterButt;
    private javax.swing.JComboBox<String> FloorBox;
    private javax.swing.JComboBox<String> FourthFloorBox;
    private javax.swing.JPanel HeadingPan;
    private javax.swing.JPanel Menu2Pan;
    private javax.swing.JPanel Menu3Pan;
    private javax.swing.JPanel MenuPan;
    private javax.swing.JLabel NotifyLb;
    private javax.swing.JLabel NotifyLb2;
    private javax.swing.JLabel NotifyLb3;
    private javax.swing.JLabel NotifyLb4;
    private javax.swing.JPanel Op1Pan;
    private javax.swing.JPanel Op2Pan;
    private javax.swing.JPanel Op3Pan;
    private javax.swing.JButton OrderRoomButt;
    private javax.swing.JButton RefreshButt;
    private javax.swing.JButton RefreshUpdate;
    private javax.swing.JButton ReturnDate;
    private javax.swing.JComboBox<String> RoomBox;
    private javax.swing.JPanel RoomFilterPan;
    private javax.swing.JPanel RoomManagementPan;
    private javax.swing.JComboBox<String> SecFloorBox;
    private javax.swing.JComboBox<String> ThrdFloorBox;
    private javax.swing.JComboBox<String> UpdateDayBox;
    private javax.swing.JComboBox<String> UpdateMonthBox;
    private javax.swing.JPanel UpdateOrderPan;
    private javax.swing.JButton UpdateRoomButt;
    private javax.swing.JTextField UpdateRoomF;
    private javax.swing.JComboBox<String> UpdateYearBox;
    private javax.swing.JButton UsingRoomButt;
    private javax.swing.JButton addBillButt;
    private javax.swing.JTextField addBillField;
    private javax.swing.JPanel addBillPan;
    private javax.swing.JButton addCusButt;
    private javax.swing.JPanel addCusPan;
    private javax.swing.JTextField addressField;
    private javax.swing.JButton billFilterButt;
    private javax.swing.JPanel billFilterPan;
    private javax.swing.JButton billListButt;
    private javax.swing.JPanel billListPan;
    private javax.swing.JButton billManageButt;
    private javax.swing.JButton blankFilterB;
    private javax.swing.JButton calculateButt;
    private javax.swing.JPanel calculateIncomePan;
    private javax.swing.JComboBox<String> calculateMonthBox;
    private javax.swing.JPanel calculatePan;
    private javax.swing.JButton checkButt;
    private javax.swing.JButton completeButt;
    private javax.swing.JCheckBox confirmCheckBox;
    private javax.swing.JButton confirmDeleteCusB;
    private javax.swing.JButton confirmDeleteRRButt;
    private javax.swing.JButton confirmOfilterB;
    private javax.swing.JButton confirmRfilterB;
    private javax.swing.JButton confirmUpdateButt;
    private javax.swing.JTextField cusCodeField;
    private javax.swing.JPanel cusListPanel;
    private javax.swing.JTextField cusNameField;
    private javax.swing.JButton customersList;
    private javax.swing.JButton customersManageB;
    private javax.swing.JComboBox<String> dayBillFilBox;
    private javax.swing.JButton deleteBillButt;
    private javax.swing.JTextField deleteBillField;
    private javax.swing.JPanel deleteBillPan;
    private javax.swing.JButton deleteCusButt;
    private javax.swing.JTextField deleteCusField;
    private javax.swing.JPanel deleteCusPan;
    private javax.swing.JTextField deleteReRoomF;
    private javax.swing.JPanel deleteReRoomPan;
    private javax.swing.JPanel displayPan;
    private javax.swing.JButton doubleRoomB;
    private javax.swing.JButton filterBillButt;
    private javax.swing.JButton findButt;
    private javax.swing.JTextField fixCusAdF;
    private javax.swing.JButton fixCusButt;
    private javax.swing.JTextField fixCusCodeF;
    private javax.swing.JPanel fixCusInfoPan;
    private javax.swing.JTextField fixCusNameF;
    private javax.swing.JTextField fixCusPhoneF;
    private javax.swing.JButton fourRoomB;
    private javax.swing.JButton incomeBymonthB;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JLabel line1LB;
    private javax.swing.JLabel line2LB;
    private javax.swing.JComboBox<String> monthBillFillBox;
    private javax.swing.JPanel monthIncomePan;
    private javax.swing.JComboBox<String> orderDateFilterBox;
    private javax.swing.JButton orderedFilterB;
    private javax.swing.JTextField phoneField;
    private javax.swing.JButton refreshCalculateB;
    private javax.swing.JButton refreshUpdateButt;
    private javax.swing.JComboBox<String> returnDateFilterBox;
    private javax.swing.JTable roomDataTbl;
    private javax.swing.JButton roomListButt;
    private javax.swing.JPanel roomListPan;
    private javax.swing.JButton roomManageButt;
    private javax.swing.JButton roomOrderFilterB;
    private javax.swing.JPanel roomOrderFilterP;
    private javax.swing.JButton roomReturnFilterB;
    private javax.swing.JPanel roomReturnFilterP;
    private javax.swing.JButton roomStatusFilterB;
    private javax.swing.JPanel roomStatusFilterP;
    private javax.swing.JButton roomStoFilterB;
    private javax.swing.JPanel roomStoFilterP;
    private javax.swing.JTextField roomToAddField;
    private javax.swing.JButton searchCusB;
    private javax.swing.JButton searchDeleteB;
    private javax.swing.JButton tripleRoomB;
    private javax.swing.JComboBox<String> uDateBox;
    private javax.swing.JComboBox<String> uMonthBox;
    private javax.swing.JComboBox<String> uYearBox;
    private javax.swing.JPanel updateOrderDate;
    private javax.swing.JTextField updateRRfield;
    private javax.swing.JPanel updateReRoomPan;
    private javax.swing.JButton updateReturnDateButt;
    private javax.swing.JPanel updateReturnDatePan;
    private javax.swing.JButton usingFilterB;
    // End of variables declaration//GEN-END:variables
}
